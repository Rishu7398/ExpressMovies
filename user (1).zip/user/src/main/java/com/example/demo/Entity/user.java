package com.example.demo.Entity;




import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="user")
public class user {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;


	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@NotEmpty
	@Pattern(regexp="^[a-zA-Z0-9]+@[a-z]+\\.[a-z]{2,3}$",message = "invalid email")
	private String emailAddress;
	@Size(min =1 , max=15 ,message = "Firstname/LastName should be maximum of 20 characters")
	private String firstName;
	@Size(min =1 , max=15 ,message = "Firstname/LastName should be maximum of 20 characters")
	private String lastName;
	@Size(min =1 , max=15 ,message="mobile no should be maximum of 10 characters")
	private long mobileNumber;
	@Size(min =7 , max=12 ,message = "password should be maximum of 15 characters")
	private String password;
	
	public user() {
		super();
		// TODO Auto-generated constructor stub
	}
	public user(Integer id,
			@NotEmpty @Pattern(regexp = "^[a-zA-Z0-9]+@[a-z]+\\.[a-z]{2,3}$", message = "invalid email") String emailAddress,
			@Size(min = 1, max = 15, message = "Firstname/LastName should be maximum of 20 characters") String firstName,
			@Size(min = 1, max = 15, message = "Firstname/LastName should be maximum of 20 characters") String lastName,
			@Size(min = 1, max = 15, message = "mobile no should be maximum of 10 characters") long mobileNumber,
			@Size(min = 7, max = 12, message = "password should be maximum of 15 characters") String password,
			String nationality,
			@Size(min = 1, max = 15, message = "passportNumber should be maximum of 12 characters") String passportNumbere,
			@Size(min = 1, max = 200, message = "permanentAddress should be maximum of 200 characters") String permanentAddress,
			@Size(min = 1, max = 200, message = "officeAddress should be maximum of 200 characters") String officeAddress,
			@Size(min = 1, max = 12, message = "personalIdentificationNumber should be maximum of 15 characters") long personalIdentificationNumber) {
		super();
		this.userId = id;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.password = password;
		this.nationality = nationality;
		this.passportNumbere = passportNumbere;
		this.permanentAddress = permanentAddress;
		this.officeAddress = officeAddress;
		this.personalIdentificationNumber = personalIdentificationNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String nationality;
	@Size(min =1 , max=15 ,message = "passportNumber should be maximum of 12 characters")
	private String passportNumbere;
	@Size(min =1 , max=200 ,message = "permanentAddress should be maximum of 200 characters")
	private String permanentAddress;
	@Size(min =1 , max=200 ,message = "officeAddress should be maximum of 200 characters")
	private String officeAddress;
	@Size(min =1 , max=12 ,message = "personalIdentificationNumber should be maximum of 15 characters")
	private long personalIdentificationNumber;
	public Integer getId() {
		return userId;
	}

	public  String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getPassportNumbere() {
		return passportNumbere;
	}
	public void setPassportNumbere(String passportNumbere) {
		this.passportNumbere = passportNumbere;
	}
	public String getPermanentAddress() {
		return permanentAddress;
	}
	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	public String getOfficeAddress() {
		return officeAddress;
	}
	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}
	public long getPersonalIdentificationNumber() {
		return personalIdentificationNumber;
	}
	public void setPersonalIdentificationNumber(long personalIdentificationNumber) {
		this.personalIdentificationNumber = personalIdentificationNumber;
	}
	@Override
	public String toString() {
		return "user [id=" + userId + ", emailAddress=" + emailAddress + ", firstName=" + firstName + ", lastName="
				+ lastName + ", mobileNumber=" + mobileNumber + ", password=" + password + ", nationality="
				+ nationality + ", passportNumbere=" + passportNumbere + ", permanentAddress=" + permanentAddress
				+ ", officeAddress=" + officeAddress + ", personalIdentificationNumber=" + personalIdentificationNumber
				+ "]";
	}
//	public user(
//			@NotEmpty @Pattern(regexp = "^[a-zA-Z0-9]+@[a-z]+\\.[a-z]{2,3}$", message = "invalid email") String emailAddress,
//			@Size(min = 1, max = 15, message = "Firstname/LastName should be maximum of 20 characters") String firstName,
//			@Size(min = 1, max = 15, message = "Firstname/LastName should be maximum of 20 characters") String lastName,
//			@Size(min = 1, max = 15, message = "mobile no should be maximum of 10 characters") long mobileNumber,
//			@Size(min = 7, max = 12, message = "password should be maximum of 15 characters") String nationality,
//			@Size(min = 1, max = 15, message = "passportNumber should be maximum of 12 characters") String passportNumbere,
//			@Size(min = 1, max = 200, message = "permanentAddress should be maximum of 200 characters") String permanentAddress,
//			@Size(min = 1, max = 200, message = "officeAddress should be maximum of 200 characters") String officeAddress,
//			@Size(min = 1, max = 12, message = "personalIdentificationNumber should be maximum of 15 characters") long personalIdentificationNumber) {
//		super();
//		this.emailAddress = emailAddress;
//		this.firstName = firstName;
//		this.lastName = lastName;
//		this.mobileNumber = mobileNumber;
//		this.nationality = nationality;
//		this.passportNumbere = passportNumbere;
//		this.permanentAddress = permanentAddress;
//		this.officeAddress = officeAddress;
//		this.personalIdentificationNumber = personalIdentificationNumber;
//	}
	
	

}
