package com.example.demo.DTO;


import com.example.demo.Entity.user;

public class userDTO {
	private int userId;

	


	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	private String emailAddress;
	
	private String firstName;

	private String lastName;
	
	private long mobileNumber;
	
	private String nationality;

	private String passportNumbere;
	
	private String permanentAddress;

	private String officeAddress;
	private String password;
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	private long personalIdentificationNumber;

	@Override
	public String toString() {
		return "userDTO [id=" + userId + ", emailAddress=" + emailAddress + ", firstName=" + firstName + ", lastName="
				+ lastName + ", mobileNumber=" + mobileNumber + ", nationality=" + nationality + ", passportNumbere="
				+ passportNumbere + ", permanentAddress=" + permanentAddress + ", officeAddress=" + officeAddress
				+ ", password=" + password + ", personalIdentificationNumber=" + personalIdentificationNumber + "]";
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public  void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPassportNumbere() {
		return passportNumbere;
	}

	public void setPassportNumbere(String passportNumbere) {
		this.passportNumbere = passportNumbere;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getOfficeAddress() {
		return officeAddress;
	}

	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}

	public long getPersonalIdentificationNumber() {
		return personalIdentificationNumber;
	}

	public void setPersonalIdentificationNumber(long personalIdentificationNumber) {
		this.personalIdentificationNumber = personalIdentificationNumber;
	}

	public userDTO(int id,String emailAddress, String firstName, String lastName, long mobileNumber, String nationality,
			String passportNumbere, String permanentAddress, String officeAddress, long personalIdentificationNumber) {
		super();
		this.userId=id;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.nationality = nationality;
		this.passportNumbere = passportNumbere;
		this.permanentAddress = permanentAddress;
		this.officeAddress = officeAddress;
		this.personalIdentificationNumber = personalIdentificationNumber;
		this.password=password;
	}
	public user crrateEntity() {
		user user=new user();
		user.setUserId(this.userId);
		user.setEmailAddress(this.emailAddress);
		user.setFirstName(this.firstName);
		user.setLastName(this.lastName);
		user.setNationality(this.nationality);
	    user.setOfficeAddress(this.officeAddress);
        user.setPassportNumbere(this.passportNumbere);
        user.setPermanentAddress(this.permanentAddress);
        user.setPersonalIdentificationNumber(this.personalIdentificationNumber);
        user.setPassportNumbere(this.password);
         return user;
	}
	public static userDTO valueOf(user user) {
		userDTO userdto=new userDTO();
		userdto.setUserId(user.getUserId());
		userdto.setEmailAddress(user.getEmailAddress());
		userdto.setFirstName(user.getFirstName());
		userdto.setLastName(user.getLastName());
		userdto.setNationality(user.getNationality());
	    userdto.setOfficeAddress(user.getOfficeAddress());
        userdto.setPassportNumbere(user.getPassportNumbere());
        userdto.setPermanentAddress(user.getPermanentAddress());
        userdto.setPersonalIdentificationNumber(user.getPersonalIdentificationNumber());
        userdto.setPassword(user.getPassword());
        return userdto;
		
	}

	public userDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
