package com.example.demo.Exception;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.demo.Utility.errormessage;



@RestControllerAdvice
public class exception {
	@ExceptionHandler(Exception.class)
	public ResponseEntity<errormessage> ExceptionHandler(Exception e){
		errormessage error =  new errormessage();
		error.setMessage(e.getMessage());
		error.setStatusCode(HttpStatus.BAD_REQUEST.value());
		error.setUrl("/user/?/?");
  	  ResponseEntity<errormessage> entity = new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
  	  return entity;
    }

}
