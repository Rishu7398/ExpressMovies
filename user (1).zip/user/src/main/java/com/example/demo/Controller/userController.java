package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.DTO.loginDTO;
import com.example.demo.DTO.userDTO;
import com.example.demo.Entity.user;
import com.example.demo.Service.UserService;

import com.example.demo.Exception.UserNotFoundException;




@RestController
@RequestMapping("/user")
public class userController {
	
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	UserService userService;
	@PostMapping("/add")
	public ResponseEntity<String> adduserData(@RequestBody userDTO user) throws Exception
	{
//		System.out.println(user.getPersonalIdentificationNumber());
		ResponseEntity<String> entity= new ResponseEntity<>(userService.adduserDetails(user), HttpStatus.CREATED);
		return entity;
	}
	
	@GetMapping("/{userId}")
	 public Optional<user> getByUserId(@PathVariable int userId) throws Exception  {
        Optional<user> users = userService.getByUserId(userId);
        		
        	
        	
        	
        	
        
        return users;
	 }

	 @PutMapping(path = "/{userId}")
		public ResponseEntity<String> updateUser(@PathVariable("userId") int id, @Valid @RequestBody userDTO userDto) throws UserNotFoundException{
			System.out.println(id + " "+ userDto);
		    String msg = userService.updateUser(id,userDto);
		    return ResponseEntity.ok(msg);
		}
	 @DeleteMapping(value = "/delete/{id}")
	 public String deleteStatus(@PathVariable int id) throws Exception
		{
			
			ResponseEntity<String> entity = new ResponseEntity<String>( userService.deleteuserStatus(id)  ,HttpStatus.FOUND );
			return entity.getBody();
			
			
		}
	
	 @PostMapping(value="/userProfile/login")
	 public String login(@RequestBody loginDTO logindto) throws Exception{
		 return userService.login(logindto);
	 }

}
