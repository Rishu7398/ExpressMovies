package com.example.demo.Service;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.catalina.User;
//import com.example.demo.Repository.userDTO;
//import org.apache.catalina.mapper.Mapper;
//import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.loginDTO;
import com.example.demo.DTO.userDTO;
import com.example.demo.Entity.user;
import com.example.demo.Repository.userRepository;

import com.example.demo.Exception.UserNotFoundException;



@Service
@Transactional
public class UserService {

	
	@Autowired
	userRepository userRepository;
	@Autowired
	ModelMapper modelMapper;
	

	public String adduserDetails(userDTO userdto) throws Exception //throws InvalidValuesException
	{
		Optional<user> optUserProfile = userRepository.findByPersonalIdentificationNumber(userdto.getPersonalIdentificationNumber());
		if(optUserProfile.isPresent()) {
			throw new Exception("User is already present");
		}
		else {
		userRepository.save(modelMapper.map(userdto, user.class));
		return "Inserted customer successfully";
		}
	}
		//System.out.println(userRepository.findByEmailAddress(userdto.getEmailAddress()));
//		if(!customerRepository.findByEmailAddress(customerdto.getEmailAddress()).isEmpty())
//		{
//			throw new InvalidValuesException("Already Exited");
//		}
//		else
//		{
//		userRepository.save(modelMapper.map(customerdto, Customer.class));
//		
//		return "Inserted customer successfully";
//		}
	public Optional<user> getByUserId(int userId) throws Exception{
		Optional<user> user1=userRepository.findById(userId);
		
		if( user1 == null ) {
			throw new UserNotFoundException("User doesnt exist");
		}

		return  user1;
		
	}
	public String updateUser(int userId, userDTO userdto)  throws UserNotFoundException {
		// TODO Auto-generated method stub
		
		user updateUser =  userRepository.findByUserId(userId);
		
		if(updateUser == null) {
			throw new UserNotFoundException("User Doesnt Exist");
		}
		updateUser.setMobileNumber(userdto.getMobileNumber());
		updateUser.setPermanentAddress(userdto.getPermanentAddress());
		updateUser.setOfficeAddress(userdto.getOfficeAddress());
		
		userRepository.save(updateUser);
		
		return "Mobilenumber, permanentAddress and OfficeAddress details are updated successfully for UserId "+userId;
	}
//	public String updateuserStatus(String password,String firstName) {
//		// TODO Auto-generated method stub
//		
//		userRepository.updateuserStatus(password, firstName);
//		
//		return "Status Updated";
//	}
	
	public String deleteuserStatus(int userId) throws Exception{
		// TODO Auto-generated method stub
		Optional<user> user1 =  userRepository.findById(userId);
		if( !user1.isPresent() ) {
			throw new UserNotFoundException("User doesnt exist");
		}
		userRepository.deleteById(userId);
		return "Status Updated";
		
	}
	public String login(loginDTO logindto) throws Exception{
		Optional<user> tempUser=userRepository.findById(logindto.getUserid());
		if(tempUser.isPresent()) {
			if(tempUser.get().getPassword().equals(logindto.getPassword())) {
				return "Logged in successFully";
			}
			else {
				return "Invalid Username and Password";
			}
		}
		else {
			return "Invalid Username and Password";
		}
	}

}
