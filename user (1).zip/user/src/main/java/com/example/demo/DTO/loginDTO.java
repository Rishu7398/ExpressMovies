package com.example.demo.DTO;

import org.springframework.beans.factory.annotation.Autowired;

public class loginDTO {
	@Autowired
	userDTO userdto;
	 
	private int userid;
	private String password;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
public static loginDTO value(userDTO userdto) {
	loginDTO logindto=new loginDTO();
	logindto.setUserid(userdto.getUserId());
	logindto.setPassword(userdto.getPassword());
	return logindto;
}
public loginDTO() {
	super();
	// TODO Auto-generated constructor stub
}
	
	

}
