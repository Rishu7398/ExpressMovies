package com.example.demo.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.user;



@Repository

public interface userRepository extends JpaRepository<user, Integer>{
	
	

//	@Query("Select c from user c where c.emailAddress =?1")
//	List<user> findByEmailAndDOB(String emailAddress);
    
  public user findByUserId(Integer userId);


    

	public Optional<user> findByPersonalIdentificationNumber(long personalIdentificationNumber);
 

//	List<user> findByFirstNameAndLastName(String firstName, String lastName);
//
//	List<user> findBypersonalIdentificationNumber(String getpersonalIdentificationNumber);

	
	
	}



	


