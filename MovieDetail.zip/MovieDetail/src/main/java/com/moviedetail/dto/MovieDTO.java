package com.moviedetail.dto;

import java.time.LocalDate;
import java.time.LocalTime;

import com.moviedetail.domain.Movie;

public class MovieDTO {

	private Integer movieId;
	private String movieTitle;
	private LocalDate date;
	private LocalTime movieRunningTime;
	public MovieDTO() {}
	public MovieDTO( String movieTitle, LocalDate date, LocalTime movieRunningTime) {
		super();
		
		this.movieTitle = movieTitle;
		this.date = date;
		this.movieRunningTime = movieRunningTime;
	}
	public MovieDTO(Integer movieId, String movieTitle, LocalDate date, LocalTime movieRunningTime) {
		super();
		this.movieId = movieId;
		this.movieTitle = movieTitle;
		this.date = date;
		this.movieRunningTime = movieRunningTime;
	}
	public Integer getMovieId() {
		return movieId;
	}
	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}
	public String getMovieTitle() {
		return movieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public LocalTime getMovieRunningTime() {
		return movieRunningTime;
	}
	public void setMovieRunningTime(LocalTime movieRunningTime) {
		this.movieRunningTime = movieRunningTime;
	}
	@Override
	public String toString() {
		return "Movie Detail [ MovieId= "+movieId+", Movie Title= "+movieTitle+", Date Released= "+date+", Movie Running Time= "+movieRunningTime+"]";
	}
	public static Movie prepareEntity(MovieDTO movDTO) {
		return new Movie(movDTO.getMovieId(),movDTO.getMovieTitle(),movDTO.getDate(),movDTO.getMovieRunningTime());
	}
	
}
