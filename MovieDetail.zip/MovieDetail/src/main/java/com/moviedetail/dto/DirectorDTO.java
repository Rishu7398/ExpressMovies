package com.moviedetail.dto;

import com.moviedetail.domain.Director;

public class DirectorDTO {

	 private Integer directorId;
	   private String firstName;
	   private String lastName;
	   private String address;
	   private String contactNumber;
	   private String email;
	   public DirectorDTO() {}
	public DirectorDTO( String firstName, String lastName, String address, String contactNumber,
			String email) {
		super();
		//this.directorId = directorId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.contactNumber = contactNumber;
		this.email = email;
	}
	public Integer getDirectorId() {
		return directorId;
	}
	public void setDirectorId(Integer directorId) {
		this.directorId = directorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	 public String toString() {
		 return "Director Details [Director Id= "+directorId+", Name= "+firstName+lastName+", Address= "+address+", Contact Number= "+contactNumber+", Email= "+email+"]";
	 }
	public static Director prepareEntity(DirectorDTO dirDTO) {
		Director director  = new Director();
		 director.setAddress(dirDTO.getAddress());
		  director.setLastName(dirDTO.getLastName());
		  director.setContactNumber(dirDTO.getContactNumber());
		  director.setEmail(dirDTO.getEmail());
		  director.setFirstName(dirDTO.getFirstName());
		  return director;
	}
}
