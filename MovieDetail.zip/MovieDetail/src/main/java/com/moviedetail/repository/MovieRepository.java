package com.moviedetail.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.moviedetail.domain.Movie;
@Repository("movieRepository")
public interface MovieRepository extends JpaRepository<Movie,Integer>{
	//@Query("from Movie m where m.Movie_Title=?1")
	@Query("select m from Movie m where m.movieTitle = ?1")
	 public Optional<Movie> findByMovieTitle(String title);
	  @Query("select m from Movie m  where m.movieTitle LIKE '%?1%' ")
	  public List<Movie> findByMovieTitle2(String title);
   
	@Modifying
	 @Query("update Movie set date=?1 where movie_title=?2")
	public Integer updateMovieWithGivenReleaseDate(LocalDate date,String title);
   
    @Modifying
	 @Query("delete from Movie where movie_title=?1 ")
	 public Integer deleteByMovieTitle(String title);
}
