package com.moviedetail;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.AbstractApplicationContext;

import com.moviedetail.dto.DirectorDTO;
import com.moviedetail.dto.MovieDTO;
//import com.moviedetails.dto.MovieDirectorDTO;
import com.moviedetail.service.MovieDetailService;

@SpringBootApplication
public class MovieDetailApplication implements CommandLineRunner{
    @Autowired
    ApplicationContext context;
    @Autowired
    MovieDetailService service;
   // static Logger logger = Logger.getLogger(MovieDetailsApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(MovieDetailApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception{
		// service=(MovieDetailsService)context.getBean("movieDetailsService");
//		 Integer directorId;
//		 String firstName;
//		 String lastName;
//		 String address;
//		 String contactNumber;
//		 String email;
//		 Integer movieId;
//		 String movieTitle;
//		 LocalDate date;
//		 LocalTime movieRunningTime;
//		 Scanner sc = new Scanner(System.in);
//		 int flag;
//		 do {
//		  try {
//			  System.out.println("Enter movie Details:");
//			  System.out.print("Enter movie Id:");
//			  movieId=sc.nextInt();
//			  System.out.print("Enter movie Title:");
//			  movieTitle=sc.next();
//			  System.out.print("Enter movie released Date:");
//			  String da=sc.next();
//			  DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
//			  date=LocalDate.parse(da,formatter);
//			  System.out.print("Enter movie Enter movie running Time:");
//			  String ti=sc.next();
//			 // DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("HH-mm-ss-ns");
//			  movieRunningTime=LocalTime.parse(ti);
//			  System.out.print("Enter Director Id:");
//			  directorId=sc.nextInt();
//			  System.out.print("Enter Director First name:");
//			  firstName=sc.next();
//			  System.out.print("Enter Director Last name:");
//			  lastName=sc.next();
//			  System.out.print("Enter Director Address:");
//			  address=sc.next();
//			  System.out.print("Enter Director Contact Number:");
//			  contactNumber=sc.next();
//			  System.out.print("Enter Director Email Id:");
//			  email=sc.next();
//			  MovieDTO movie1=new MovieDTO(movieId,movieTitle,date,movieRunningTime);
//			  DirectorDTO director1=new DirectorDTO(directorId,firstName,lastName,address,contactNumber,email);
//			  //MovieDirectorDTO moviedirector1=new MovieDirectorDTO(movie1,director1);
//			  service.insertDetails(movie1,director1);
//		  }catch(Exception e) {
//			  System.out.print(e);
//		  }
//		  System.out.print("Want to enter more movie details (0/1):");
//		  flag=sc.nextInt();
//		 }while(flag==1);
		LocalDate date;
		String da="24-Dec-2000";
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		date=LocalDate.parse(da,formatter);
		LocalTime movieRunningTime;
		String ti="03:00:20";
		movieRunningTime=LocalTime.parse(ti);
		MovieDTO movie1=new MovieDTO("RamRaj",date,movieRunningTime);
		List<DirectorDTO> directorList1=Arrays.asList(new DirectorDTO("Papu","Kumar","Omnagar","9867546755","papu@gmail.com"),
				new DirectorDTO("Tapu","Kumar","Ramnagar","9867540055","tapu@gmail.com")) ;
		service.insertDetails(movie1,directorList1);
		
		service.searchBasedOnTitle("Raj");
		service.updateReleaseDate(LocalDate.of(2014, 6, 1),"ABC");
		System.out.println("******************** Get all Directors from Movie Title *****************");
		service.getDirectorListFromTitle("ABC");
		
		System.out.println(" **************************Get all Movies from Director Name**********************");
        service.getMovieListFromDirectorName("Tapu");
        System.out.println(service.displayAll().toString());
         
	}

}
