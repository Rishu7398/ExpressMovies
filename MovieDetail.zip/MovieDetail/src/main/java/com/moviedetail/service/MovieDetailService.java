package com.moviedetail.service;

import java.time.LocalDate;
import java.util.List;

import com.moviedetail.domain.Movie;
import com.moviedetail.dto.DirectorDTO;
import com.moviedetail.dto.MovieDTO;

public interface MovieDetailService {
    public void insertDetails(MovieDTO movieDTO,List<DirectorDTO> directorDTOList);
    public void searchBasedOnTitle(String title);
    void updateReleaseDate(LocalDate releaseDate,String movieTitle);
    void getDirectorListFromTitle(String title);
    void getMovieListFromDirectorName(String name);
    List<Movie> displayAll();
    void deleteBasedOnMovieTitle(String Title);
}
