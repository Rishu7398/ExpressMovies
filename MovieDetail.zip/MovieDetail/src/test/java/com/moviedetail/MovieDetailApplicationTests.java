package com.moviedetail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDetailApplicationTests {

	@Test
	void contextLoads() {
	}

}
