package com.workitem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkitemApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkitemApplication.class, args);
	}

}
