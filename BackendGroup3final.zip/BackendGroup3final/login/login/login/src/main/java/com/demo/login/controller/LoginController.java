package com.demo.login.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.login.dto.LoginDTO;
import com.demo.login.dto.ResponseMessage;
import com.demo.login.service.LoginService;

@RestController()
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	LoginService loginService;
	@PostMapping("/signin")
	public ResponseEntity<ResponseMessage> authenticateUser(@RequestBody LoginDTO loginDTO) throws Exception{
		System.out.println(loginDTO);
		String message=loginService.authenticateUser(loginDTO);
	    ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		return ResponseEntity.ok(response);
	}
	
}
