package com.demo.login.dto;

//import javax.validation.constraints.Pattern;
//import javax.validation.constraints.Size;

import com.demo.login.entity.Login;

public class LoginDTO {

	private String userName;
	
	private String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Login convertDTOtoEntity(LoginDTO loginDTO) {
		Login login =new Login();
		login.setUserName(loginDTO.getUserName());
		login.setPassword(loginDTO.getPassword());
		return login;
	}
}
