package com.demo.login.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.login.dto.LoginDTO;
import com.demo.login.entity.Login;
import com.demo.login.repository.LoginRepository;

@Service
public class LoginService {
	@Autowired
	LoginRepository loginRepository;
	public String authenticateUser(LoginDTO loginDTO) throws Exception{
		String userName=loginDTO.getUserName();
		//Login l=new Login();
		System.out.println("Hello");
		Optional<Login> login =loginRepository.findById(userName);
		System.out.println(login.get());
		if(!login.isEmpty()) {
			Login l=login.get();
			if(l.getPassword().equals(loginDTO.getPassword())) {
				return "Login Succesfull";
			}
			else {
				return "Wrong Password";
			}
		}
		else {
			throw new Exception("Wrong Username");
		}
	}
	public List<LoginDTO> getUsers() {
		// TODO Auto-generated method stub
		List<Login> l = loginRepository.findAll();
		List<LoginDTO> lDTO= l.stream().map(i->i.convertEntitytoDTO(i)).toList();
		return lDTO;
	}
}
