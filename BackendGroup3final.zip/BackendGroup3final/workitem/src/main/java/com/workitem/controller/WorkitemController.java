package com.workitem.controller;


import java.util.List;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.workitem.DTO.ResponseMessage;
import com.workitem.DTO.TerminalDTO;

import com.workitem.DTO.VehicleWorkitemDTO;
import com.workitem.DTO.WorkitemDTO;
import com.workitem.entity.VehicleWorkitem;
import com.workitem.entity.WorkitemTerminal;
import com.workitem.repository.VehicleWorkitemRepository;
import com.workitem.repository.WorkitemTerminalRepository;
import com.workitem.service.WorkitemService;

@RestController
@RequestMapping("/ftrc")
public class WorkitemController {
   
	@Autowired
	WorkitemService service;
	
	@Autowired
	private DiscoveryClient client;
	
	@Autowired
	RestTemplate template;
	
	String terminalUri;
	String vehicleUri;
	
	@Autowired
	WorkitemTerminalRepository workitemTerminalRepository;
	
	@Autowired
	VehicleWorkitemRepository vehicleWorkitemRepository;
	
	@PostMapping(value="/workitems")
	public ResponseEntity<WorkitemDTO> createWorkitem(@RequestBody WorkitemDTO newWorkitem){
		WorkitemDTO workitemDTO=service.createWorkitem(newWorkitem);
		ResponseEntity<WorkitemDTO> entity = new ResponseEntity<>(workitemDTO,HttpStatus.ACCEPTED);
		return entity;
	}
	@PutMapping(value="/workitems/{workitemId}")
	public ResponseEntity<ResponseMessage> updateWorkitem(@PathVariable String workitemId,@RequestBody WorkitemDTO workitemDTO){
		String message=service.updateWorkitemId(workitemId, workitemDTO);
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		ResponseEntity<ResponseMessage> entity = new ResponseEntity<>(response,HttpStatus.ACCEPTED);
		return entity;
	}
	
	@GetMapping(value="/workitems/{fromCountry}")
	ResponseEntity<List<String>> fetchAvailableHarborLocations(@PathVariable String fromCountry) throws Exception{
		List<String> str = service.fetchAvailableHarborLocations(fromCountry);
		ResponseEntity<List<String>> entity = new ResponseEntity<>(str,HttpStatus.ACCEPTED);
		return entity;
	}
	@GetMapping(value="/workitems")
	ResponseEntity<List<WorkitemDTO>> fetchWorkitemDetails(){
		List<WorkitemDTO> workitems=service.fetchWorkitemDetails();
		ResponseEntity<List<WorkitemDTO>> entity = new ResponseEntity<>(workitems,HttpStatus.ACCEPTED);
		return entity;
	}
	
	@GetMapping(value="/workitems/managed-status/{workitemId}")
	ResponseEntity<VehicleWorkitemDTO> fetchWorkitemStatus(@PathVariable String workitemId) throws Exception {
		VehicleWorkitemDTO dto = service.fetchWorkitemStatus(workitemId);
		ResponseEntity<VehicleWorkitemDTO> entity = new ResponseEntity<>(dto,HttpStatus.ACCEPTED);
		return entity;
	}
	
	@GetMapping(value="/workitems/managed-user/{userId}")
	ResponseEntity<List<WorkitemDTO>> trackWorkitemByUser(@PathVariable Long userId){
		List<WorkitemDTO> workitems=service.trackWorkitemByUser(userId);
		ResponseEntity<List<WorkitemDTO>> entity = new ResponseEntity<>(workitems,HttpStatus.ACCEPTED);
		return entity;
	}
	
	@GetMapping(value="/workitems/managed-vehicle/{vehicleNumber}")
	ResponseEntity<VehicleWorkitemDTO> fetchWorkitemDetailsByVehicleNumber(@PathVariable String vehicleNumber){
		VehicleWorkitemDTO dto = service.fetchWorkItemDetailsByVehicleNumber(vehicleNumber);
		ResponseEntity<VehicleWorkitemDTO> entity = new ResponseEntity<>(dto,HttpStatus.ACCEPTED);
		return entity;
	}
//	
//	@PostMapping(value="/workitems/managed-vehicle/{workitemId")
//	public ResponseEntity<String> allocateVehicle(@PathVariable String workitemId, @RequestBody ){
//		
//	}
	
	
	@CircuitBreaker(name="workitemService",fallbackMethod="updateWorkitemStatusFallback")
	@PutMapping(value="/workitems/managed-update/{workitemId}")
	ResponseEntity<ResponseMessage> updateWorkitemStatus(@PathVariable String workitemId) throws Exception{
		String message = service.updateWorkitemStatus(workitemId);
		Optional<WorkitemTerminal> tempWorkitemTerminal=workitemTerminalRepository.findById(workitemId);
		String terminalId =tempWorkitemTerminal.get().getTerminalId();
//        List<ServiceInstance> listOfTerminalInstance = client.getInstances("TerminalMS");
//        if(listOfTerminalInstance!=null && !listOfTerminalInstance.isEmpty()) {
//        	terminalUri=listOfTerminalInstance.get(0).getUri().toString();
//        }
		WorkitemDTO workitemDTO = service.fetchWorkitemById(workitemId);
		String quantityPart[]=workitemDTO.getQuantity().split(" ");
		Integer quantity=Integer.parseInt(quantityPart[0]);
		 template.put("http://TerminalMS/ftr/terminals/"+terminalId+"/"+quantity,String.class);
		Optional<VehicleWorkitem> tempVehicle = vehicleWorkitemRepository.findById(workitemId);
		String vehicleNumber=tempVehicle.get().getVehicleNumber();
//		List<ServiceInstance> listOfVehicleInstance = client.getInstances("VehicleMS");
//        if(listOfVehicleInstance!=null && !listOfVehicleInstance.isEmpty()) {
//        	vehicleUri=listOfVehicleInstance.get(0).getUri().toString();
//        }
		String s = template.getForObject("http://VehicleMS/ftrd/vehicles/"+vehicleNumber+"/Active",String.class);
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		ResponseEntity<ResponseMessage> entity = new ResponseEntity<>(response,HttpStatus.ACCEPTED);
	
		return entity;
	}
	ResponseEntity<ResponseMessage> updateWorkitemStatusFallback(String workitemId, Throwable throwable){
		String message="Workitem Status not updated";
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
	}
	
	@CircuitBreaker(name="workitemService",fallbackMethod="assignTerminalForWorkitemFallback")
	@PostMapping(value="/workitems/managed-terminal/{workitemId}")
	ResponseEntity<ResponseMessage> assignTerminalForWorkitem(@PathVariable String workitemId) throws Exception{
		WorkitemDTO workitemDTO = service.getItemTypeByWorkitemId(workitemId);
		System.out.println("Hello");
		
//		List<ServiceInstance> listOfTerminalInstance = client.getInstances("TerminalMS");
//        if(listOfTerminalInstance!=null && !listOfTerminalInstance.isEmpty()) {
//        	terminalUri=listOfTerminalInstance.get(0).getUri().toString();
//        }
		
	//	TerminalDTO terminalDTO = template.getForObject(terminalUri+"/ftr/terminals/fetchAvailableTerminalByItemType/"+workitemDTO.getItemType(),TerminalDTO.class);
		TerminalDTO terminalDTO = template.getForObject("http://TerminalMS/ftr/terminals/fetchAvailableTerminalByItemType/"+workitemDTO.getItemType(),TerminalDTO.class);	
		//TerminalDTO terminalDTO = service.findTerminalForWorkitem(workitemDTO,terminals);
		String message = service.assignTerminalForWorkitem(workitemId, terminalDTO.getTerminalId());
		System.out.println("Hello dear");
		String quantityPart[]=workitemDTO.getQuantity().split(" ");
		Integer quantity=Integer.parseInt(quantityPart[0]);
	//	 new RestTemplate().put(terminalUri+"/ftr/terminals/"+terminalDTO.getTerminalId()+"/"+quantity,String.class);
		template.put("http://TerminalMS/ftr/terminals/"+terminalDTO.getTerminalId()+"/"+quantity,String.class);
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		ResponseEntity<ResponseMessage> entity = new ResponseEntity<>(response,HttpStatus.ACCEPTED);
		
		return entity;
	}
	
	ResponseEntity<ResponseMessage> assignTerminalForWorkitemFallback(String workitemId, Throwable throwable){
	
		String message="Terminal not able to assign for Workitem";
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
	}
	
}
