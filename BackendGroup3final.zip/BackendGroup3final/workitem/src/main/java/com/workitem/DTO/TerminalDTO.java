package com.workitem.DTO;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



public class TerminalDTO {
	
private String terminalId;
@Size(min=3, max=20, message="Terminal name should have 3-20 charcters")
private String terminalName;
@Size(min=3,max=20, message="Country name should have 3-28 charcters")
private String country;
@Size(min=4, max=20, message="Item type should have 3-20 charcters")
private String itemType;
@Pattern(regexp="^[0-9]-[a-zA-Z]{0,25}$", message="Invalid terminal Description")
private String terminalDescription;
@Size (max=5, message="Capacity should not excced 5 digits")
private Integer capacity;
@Size (max=5, message="Capacity should not excced 5 digits")
private Integer availableCapacity;
@Pattern(regexp="Available Not Available available not available not Available", message="Inputs should be 'Available' or 'Not Available'")
private String status;
@Size(min=5, max=25, message="Harbour Location should have a 5-25 characters") 
private String harborLocation;
public TerminalDTO() {
	super();
}
public TerminalDTO(String terminalId,
		@Size(min = 3, max = 20, message = "Terminal name should have 3-20 charcters") String terminalName,
		@Size(min = 3, max = 20, message = "Country name should have 3-28 charcters") String country,
		@Size(min = 4, max = 20, message = "Item type should have 3-20 charcters") String itemType,
		@Pattern(regexp = "^[0-9]-[a-zA-Z]{0,25}$", message = "Invalid terminal Description") String terminalDescription,
		@Size(max = 5, message = "Capacity should not excced 5 digits") Integer capacity,
		@Size(max = 5, message = "Capacity should not excced 5 digits") Integer availableCapacity,
		@Pattern(regexp = "Available Not Available available not available not Available", message = "Inputs should be 'Available' or 'Not Available'") String status,
		@Size(min = 5, max = 25, message = "Harbour Location should have a 5-25 characters") String harborLocation) {
	super();
	this.terminalId = terminalId;
	this.terminalName = terminalName;
	this.country = country;
	this.itemType = itemType;
	this.terminalDescription = terminalDescription;
	this.capacity = capacity;
	this.availableCapacity = availableCapacity;
	this.status = status;
	this.harborLocation = harborLocation;
}
public String getTerminalId() {
	return terminalId;
}
public void setTerminalId(String terminalId) {
	this.terminalId = terminalId;
}
public String getTerminalName() {
	return terminalName;
}
public void setTerminalName(String terminalName) {
	this.terminalName = terminalName;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getItemType() {
	return itemType;
}
public void setItemType(String itemType) {
	this.itemType = itemType;
}
public String getTerminalDescription() {
	return terminalDescription;
}
public void setTerminalDescription(String terminalDescription) {
	this.terminalDescription = terminalDescription;
}
public Integer getCapacity() {
	return capacity;
}
public void setCapacity(Integer capacity) {
	this.capacity = capacity;
}
public Integer getAvailableCapacity() {
	return availableCapacity;
}
public void setAvailableCapacity(Integer availableCapacity) {
	this.availableCapacity = availableCapacity;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getHarborLocation() {
	return harborLocation;
}
public void setHarborLocation(String harborLocation) {
	this.harborLocation = harborLocation;
}
  
}