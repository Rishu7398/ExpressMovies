package com.workitem.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.workitem.entity.VehicleWorkitem;

@Repository
public interface VehicleWorkitemRepository extends JpaRepository<VehicleWorkitem,String> {
	
	@Query("Select c from VehicleWorkitem c where c.vehicleNumber=?1")
	Optional<VehicleWorkitem> findByVehicleNumber(String vehicleNumber);
	@Transactional
	@Modifying
	@Query("update VehicleWorkitem v set v.assignedWorkitemStatus=?2 where v.workitemId=?1")
     void updateStatusCompleted(String workitemId,String assignedWorkitemStatus);
}
