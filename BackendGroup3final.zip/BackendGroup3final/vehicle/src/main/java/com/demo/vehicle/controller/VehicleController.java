package com.demo.vehicle.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.vehicle.DTO.ResponseMessage;
import com.demo.vehicle.DTO.VehicleDTO;
import com.demo.vehicle.service.VehicleService;

@RestController
@RequestMapping("/ftrd")
public class VehicleController {

	@Autowired
	VehicleService service;
	
	@PostMapping(value="/vehicles")
	public ResponseEntity<ResponseMessage> insertNewVehicle(@RequestBody VehicleDTO newVehicleDTO) throws Exception{
		String message=service.insertNewVehicle(newVehicleDTO);
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		ResponseEntity<ResponseMessage> entity = new ResponseEntity<>(response,HttpStatus.ACCEPTED);
		return entity;
	}
	@GetMapping(value="/vehicles")
	ResponseEntity<List<VehicleDTO>> fetchVehicleDetails(){
		List<VehicleDTO> vehicles=service.fetchVehicleDetails();
		ResponseEntity<List<VehicleDTO>> entity = new ResponseEntity<>(vehicles,HttpStatus.ACCEPTED);
		return entity;
	}
	@PutMapping(value="/vehicles/{vehicleNumber}")
	public ResponseEntity<ResponseMessage> updateVehicleStatus(@PathVariable String vehicleNumber,@RequestBody VehicleDTO dto) throws Exception{
		String message = service.updateVehicleStatus(vehicleNumber,dto);
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		ResponseEntity<ResponseMessage> entity = new ResponseEntity<>(response,HttpStatus.ACCEPTED);
		
		return entity;
	}
	
	     //this below method is only for WorkitemMS purpose
	
	@GetMapping(value="/vehicles/{vehicleNumber}/{vehicleStatus}")
	public ResponseEntity<String> updateVehicleStatusActive(@PathVariable String vehicleNumber,@PathVariable String vehicleStatus) throws Exception{
		String message = service.updateVehicleStatusActive(vehicleNumber,vehicleStatus);
		ResponseEntity<String> entity = new ResponseEntity<>(message,HttpStatus.ACCEPTED);
		return entity;
	}
	
	@GetMapping(value="/vehicles/managed-name/{vehicleName}")
	public ResponseEntity<List<VehicleDTO>> fetchVehicleDetailsByVehicleName(@PathVariable String vehicleName){
		
		List<VehicleDTO> vehiclesDTO = service.fetchVehicleDetailsByVehicleName(vehicleName);
		
		ResponseEntity<List<VehicleDTO>> entity = new ResponseEntity<>(vehiclesDTO,HttpStatus.ACCEPTED);
		return entity;
	}
	
	@GetMapping(value="/vehicles/managed-number/{vehicleNumber}")
	public ResponseEntity<VehicleDTO> fetchVehicleDetailsByVehicleNumber(@PathVariable String vehicleNumber) throws Exception{
		VehicleDTO vehicleDTO = service.fetchVehicleDetailsByVehicleNumber(vehicleNumber);
		ResponseEntity<VehicleDTO> entity = new ResponseEntity<>(vehicleDTO,HttpStatus.ACCEPTED);
		return entity;
	}

	
	@DeleteMapping(value="/vehicles/{vehicleNumber}")
	public ResponseEntity<ResponseMessage> removeVehicle(@PathVariable String vehicleNumber) throws Exception{
		String message = service.removeVehicle(vehicleNumber);
		ResponseMessage response = new ResponseMessage();
	    response.setMessage(message);
		ResponseEntity<ResponseMessage> entity = new ResponseEntity<>(response,HttpStatus.ACCEPTED);
		
		return entity;
	}
}
