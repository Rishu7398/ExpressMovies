package com.demo.vehicle.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.demo.vehicle.entity.Vehicle;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle,String>  {

	@Transactional
	@Modifying
	@Query("update Vehicle v set v.vehicleStatus=?1 where v.vehicleNumber=?2")
	void updateVehicleStatusById(String vehicleStatus,String vehicleNumber);
	
	@Query("select v from Vehicle v where v.vehicleName=?1")
	List<Vehicle> findByVehicleName(String vehicleName);
}
