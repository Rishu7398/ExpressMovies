package com.demo.vehicle.DTO;

import java.time.LocalDate;

import com.demo.vehicle.entity.Vehicle;

public class VehicleDTO {

	private String vehicleNumber;
	private String vehicleName;
	private Long maxLiftingCapacity;
	private LocalDate retireDate;
	private String vehicleStatus;
	private String country;
	private String harborLocation;
	public VehicleDTO() {
		super();
	}
	public VehicleDTO(String vehicleNumber, String vehicleName, Long maxLiftingCapacity, LocalDate retireDate,
			String vehicleStatus, String country, String harborLocation) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.vehicleName = vehicleName;
		this.maxLiftingCapacity = maxLiftingCapacity;
		this.retireDate = retireDate;
		this.vehicleStatus = vehicleStatus;
		this.country = country;
		this.harborLocation = harborLocation;
	}
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public Long getMaxLiftingCapacity() {
		return maxLiftingCapacity;
	}
	public void setMaxLiftingCapacity(Long maxLiftingCapacity) {
		this.maxLiftingCapacity = maxLiftingCapacity;
	}
	public LocalDate getRetireDate() {
		return retireDate;
	}
	public void setRetireDate(LocalDate retireDate) {
		this.retireDate = retireDate;
	}
	public String getVehicleStatus() {
		return vehicleStatus;
	}
	public void setVehicleStatus(String vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getHarborLocation() {
		return harborLocation;
	}
	public void setHarborLocation(String harborLocation) {
		this.harborLocation = harborLocation;
	}
	public static Vehicle createEntity(VehicleDTO dto) {
		Vehicle vehicle = new Vehicle();
		vehicle.setCountry(dto.getCountry());
		vehicle.setHarborLocation(dto.getHarborLocation());
		vehicle.setMaxLiftingCapacity(dto.getMaxLiftingCapacity());
		vehicle.setRetireDate(dto.getRetireDate());
		vehicle.setVehicleName(dto.getVehicleName());
		vehicle.setVehicleNumber(dto.getVehicleNumber());
		vehicle.setVehicleStatus(dto.getVehicleStatus());
		return vehicle;
	}
	public static VehicleDTO valueOf(Vehicle vehicle) {
		VehicleDTO vehicleDTO = new VehicleDTO();
		vehicleDTO.setCountry(vehicle.getCountry());
		vehicleDTO.setHarborLocation(vehicle.getHarborLocation());
		vehicleDTO.setMaxLiftingCapacity(vehicle.getMaxLiftingCapacity());
		vehicleDTO.setRetireDate(vehicle.getRetireDate());
		vehicleDTO.setVehicleName(vehicle.getVehicleName());
		vehicleDTO.setVehicleNumber(vehicle.getVehicleNumber());
		vehicleDTO.setVehicleStatus(vehicle.getVehicleStatus());
		return vehicleDTO;
	}
}
