package com.demo.vehicle.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.demo.vehicle.DTO.VehicleDTO;
import com.demo.vehicle.entity.Vehicle;
import com.demo.vehicle.repository.VehicleRepository;


@Service("vehicleService")
@Transactional
public class VehicleService {

	@Autowired
	VehicleRepository vehicleRepository;
	
	public String insertNewVehicle(VehicleDTO vehicleDTO) throws Exception{
		Optional<Vehicle> tempVehicle = vehicleRepository.findById(vehicleDTO.getVehicleNumber());
		if(tempVehicle.isPresent()) {
			throw new Exception("Invalid Data");
		}
		else {
			vehicleRepository.saveAndFlush(VehicleDTO.createEntity(vehicleDTO));
			return "Vehicle details are inserted successfully with vehicle number: "+vehicleDTO.getVehicleNumber();
		}
	}
	public List<VehicleDTO> fetchVehicleDetails(){
		List<Vehicle> vehicles =vehicleRepository.findAll();
		List<VehicleDTO> vehiclesDTO = new ArrayList<>();
		for(Vehicle vehicle : vehicles) {
			vehiclesDTO.add(VehicleDTO.valueOf(vehicle));
		}
		return vehiclesDTO;
	}
	
	public String updateVehicleStatus(String vehicleNumber,VehicleDTO dto) throws Exception {
		Optional<Vehicle> tempVehicle = vehicleRepository.findById(vehicleNumber);
		String message;
		if(tempVehicle.isPresent()) {
			vehicleRepository.updateVehicleStatusById(dto.getVehicleStatus(),vehicleNumber);
			message="Vehicle Status of " + vehicleNumber + " updated SuccessFully!";
			return message;
		}
		else {
			throw new Exception("Invalid Data");
		}
	}
	public String updateVehicleStatusActive(String vehicleNumber,String vehicleStatus) throws Exception{
		Optional<Vehicle> tempVehicle = vehicleRepository.findById(vehicleNumber);
		String message;
		if(tempVehicle.isPresent()) {
			vehicleRepository.updateVehicleStatusById(vehicleStatus,vehicleNumber);
			message="Vehicle Status of " + vehicleNumber + " updated SuccessFully!";
			return message;
		}
		else {
			throw new Exception("Invalid Data");
		}
	}
	public List<VehicleDTO> fetchVehicleDetailsByVehicleName(String vehicleName){
		List<Vehicle> vehicles = vehicleRepository.findByVehicleName(vehicleName);
		List<VehicleDTO> vehiclesDTO = new ArrayList<>();
		for(Vehicle vehicle: vehicles) {
			vehiclesDTO.add(VehicleDTO.valueOf(vehicle));
		}
		return vehiclesDTO;
	}
	
	public VehicleDTO fetchVehicleDetailsByVehicleNumber(String vehicleNumber) throws Exception{
		Optional<Vehicle> tempVehicle=vehicleRepository.findById(vehicleNumber);
		if(tempVehicle.isPresent()) {
			VehicleDTO vehicleDTO = VehicleDTO.valueOf(tempVehicle.get());
			return vehicleDTO;
		}
		else {
			throw new Exception("Invalid Vehicle Number");
		}
	}
	
	public String removeVehicle(String vehicleNumber) throws Exception{
		Optional<Vehicle> tempVehicle =  vehicleRepository.findById(vehicleNumber);
		if( !tempVehicle.isPresent() ) {
			throw new Exception("Vehicle details not found");
		}
		vehicleRepository.deleteById(vehicleNumber);
		return "Vehicle "+vehicleNumber + " details are removed successfully";
		
	}
}
