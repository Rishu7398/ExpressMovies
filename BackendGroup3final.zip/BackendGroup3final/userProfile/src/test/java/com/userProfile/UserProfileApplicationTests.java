package com.userProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
