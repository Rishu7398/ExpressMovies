package com.userProfile.DTO;

public class loginDTO {
	private int userId;
	private String password;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
public static loginDTO value(UserProfileDTO userdto) {
	loginDTO logindto=new loginDTO();
	logindto.setUserId(userdto.getUserId());
	logindto.setPassword(userdto.getPassword());
	return logindto;
}
public loginDTO() {
	super();
	// TODO Auto-generated constructor stub
}
public loginDTO(int userId, String password) {
	super();
	this.userId = userId;
	this.password = password;
}
	
	


}
