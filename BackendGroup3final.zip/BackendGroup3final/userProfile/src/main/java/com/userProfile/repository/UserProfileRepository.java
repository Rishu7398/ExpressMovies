package com.userProfile.repository;

import com.userProfile.entity.UserProfile;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserProfileRepository  extends JpaRepository<UserProfile,Integer>{

	public Optional<UserProfile> findByPersonalIdentificationNumber(long personalIdentificationNumber);
	
	@Transactional
	@Modifying
	@Query("update UserProfile u set u.mobileNumber=?1, u.permanentAddress=?2, u.officeAddress=?3 where u.userId=?4")
	public void updatePAddressMNumberOAddress(long mobileNumber,String permanentAddress,String officeAddress, int userId);
}
