package com.userProfile.DTO;

import com.userProfile.entity.UserProfile;

public class UserProfileDTO {

	private int userId;
	
    private String emailId;
	
	private String firstName;

	private String lastName;
	
	private long mobileNumber;
	
	private String nationality;

	private String passportNumber;
	
	private String permanentAddress;

	private String officeAddress; 
	
	private String password;  
	
	private long personalIdentificationNumber;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getOfficeAddress() {
		return officeAddress;
	}

	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPersonalIdentificationNumber() {
		return personalIdentificationNumber;
	}

	public void setPersonalIdentificationNumber(long personalIdentificationNumber) {
		this.personalIdentificationNumber = personalIdentificationNumber;
	}

	public UserProfileDTO(int userId, String emailId, String firstName, String lastName, long mobileNumber,
			String nationality, String passportNumber, String permanentAddress, String officeAddress, String password,
			long personalIdentificationNumber) {
		super();
		this.userId = userId;
		this.emailId = emailId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.nationality = nationality;
		this.passportNumber = passportNumber;
		this.permanentAddress = permanentAddress;
		this.officeAddress = officeAddress;
		this.password = password;
		this.personalIdentificationNumber = personalIdentificationNumber;
	}

	public UserProfileDTO() {
		super();
	}
	public static UserProfile crrateEntity(UserProfileDTO dto) {
		UserProfile userProfile=new UserProfile();
		userProfile.setUserId(dto.getUserId());
		userProfile.setEmailId(dto.getEmailId());
		userProfile.setFirstName(dto.getFirstName());
		userProfile.setLastName(dto.getLastName());
		userProfile.setNationality(dto.getNationality());
	    userProfile.setOfficeAddress(dto.getOfficeAddress());
        userProfile.setPassportNumber(dto.getPassportNumber());
        userProfile.setPermanentAddress(dto.getPermanentAddress());
        userProfile.setPersonalIdentificationNumber(dto.getPersonalIdentificationNumber());
        userProfile.setPassword(dto.getPassword());
        userProfile.setMobileNumber(dto.getMobileNumber());
         return userProfile;
	}
	public static UserProfileDTO valueOf(UserProfile userProfile) {
		UserProfileDTO userProfileDTO=new UserProfileDTO();
		userProfileDTO.setUserId(userProfile.getUserId());
		userProfileDTO.setEmailId(userProfile.getEmailId());
		userProfileDTO.setFirstName(userProfile.getFirstName());
		userProfileDTO.setLastName(userProfile.getLastName());
		userProfileDTO.setNationality(userProfile.getNationality());
	    userProfileDTO.setOfficeAddress(userProfile.getOfficeAddress());
        userProfileDTO.setPassportNumber(userProfile.getPassportNumber());
        userProfileDTO.setPermanentAddress(userProfile.getPermanentAddress());
        userProfileDTO.setPersonalIdentificationNumber(userProfile.getPersonalIdentificationNumber());
        userProfileDTO.setPassword(userProfile.getPassword());
        userProfileDTO.setMobileNumber(userProfile.getMobileNumber());
         return userProfileDTO;
	}
}
