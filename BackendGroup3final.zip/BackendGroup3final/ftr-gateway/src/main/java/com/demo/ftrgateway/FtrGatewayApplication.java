package com.demo.ftrgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FtrGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FtrGatewayApplication.class, args);
	}

}
