package com.demo.ftrgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FtrGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
