package com.demo.terminal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.terminal.dto.TerminalDTO;
import com.demo.terminal.entity.Terminal;
import com.demo.terminal.exception.ItemNotFoundException;
import com.demo.terminal.repository.TerminalRepository;

@Service
public class TerminalService {

	private static int count=11;
	@Autowired
	TerminalRepository terminalRepository;
	public List<TerminalDTO> fetchFTRTerminals(){
		List<Terminal> t = terminalRepository.findAll();
		List<TerminalDTO> tDTO = t.stream().map(i->i.convertEntitytoDTO(i)).toList();
		System.out.println(t);
		return tDTO;
	}
	
	
	public List<TerminalDTO> fetchTerminalByItemType(String itemType) throws ItemNotFoundException{

		List<Terminal> t =terminalRepository.fetchTerminalByItemType(itemType);

		if(!t.isEmpty()) { 
			List<TerminalDTO> tDTO=t.stream().map(i->i.convertEntitytoDTO(i)).toList(); 
			System.out.println(tDTO); 
			return tDTO;
		} else {

		throw new ItemNotFoundException("No such Item type exists");

		}} 
	public TerminalDTO fetchAvailableTerminalByItemType(String itemType) throws ItemNotFoundException{

		List<Terminal> t =terminalRepository.fetchTerminalByItemType(itemType);

		if(!t.isEmpty()) { 
			for(Terminal terminal:t) {
				if(terminal.getStatus().equals("Available"));
				return terminal.convertEntitytoDTO(terminal);
			}
			throw new ItemNotFoundException("No Available terminal for such itemType");
		} else {

		throw new ItemNotFoundException("No such Item type exists");

		}} 
	public TerminalDTO fetchTerminalByTerminalId(String id) throws ItemNotFoundException { 
		Optional<Terminal> t=terminalRepository.findById(id);
	if(!t.isEmpty()) {
		Terminal terminal=t.get(); 
		return terminal.convertEntitytoDTO(terminal);
   } else {
		throw new ItemNotFoundException("Terminal Details not found for id "+id);

		}
	}

	public String removeTerminal(String id) throws ItemNotFoundException {

		if (!terminalRepository.findById(id).isEmpty()) { 
			terminalRepository.deleteById(id);
		return "Terminal Details are deleted";
		}else {
			throw new ItemNotFoundException("Terminal details are not found for id "+id);
		}
	}
	public String updateTerminal(String terminalId,Integer newCapacity) throws ItemNotFoundException{
		Terminal terminal = terminalRepository.findByTerminalId(terminalId);
		if(terminal.getTerminalId().isBlank()) {
			throw new ItemNotFoundException("Terminal details not found for Id: "+terminalId);
		}
		else {
			int availableCapacity = terminal.getAvailableCapacity();
			if(availableCapacity>=newCapacity) {
				if(availableCapacity==newCapacity) {
					terminal.setStatus("NotAvailable");
				}
				terminal.setAvailableCapacity(availableCapacity-newCapacity);
				terminalRepository.saveAndFlush(terminal);
				return "Terminal capacity is successfully reduced for Id: "+terminalId;
			}
			else {
			return "Given capacity is more than available capacity";
		}}
	}
	 public String insertNewTerminal(TerminalDTO terminalDTO) throws ItemNotFoundException {
		 String s = terminalDTO.getCountry();
		 System.out.println(terminalDTO.getCountry());
		 if(s.isEmpty()) {
			 throw new ItemNotFoundException("Country Name Should be Present, Please Check");
		 }
		 String terminalId = "T"+generateId();
		 terminalDTO.setTerminalId(terminalId);
		 terminalRepository.saveAndFlush(terminalDTO.convertDTOtoEntity(terminalDTO));
		 return "Successfully Added";
	 }
	 private int generateId() {
		 count=count+1;
		 int id = count;
		 return id;
	 }
	
}
