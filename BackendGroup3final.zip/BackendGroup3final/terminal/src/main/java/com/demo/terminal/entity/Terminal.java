package com.demo.terminal.entity;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.demo.terminal.dto.TerminalDTO;
@Entity
@Table(name="ftr_terminals")
public class Terminal {
    
	@Id
	private String terminalId;
	
	private String terminalName;

	private String country;

	private String itemType;

	private String terminalDescription;

	private Integer capacity;

	private Integer availableCapacity;

	private String status;

	private String harborLocation;
	
	public Terminal(String terminalId, String terminalName, String country, String itemType, String terminalDescription,
			Integer capacity, Integer availableCapacity, String status, String harborLocation) {
		super();
		this.terminalId = terminalId;
		this.terminalName = terminalName;
		this.country = country;
		this.itemType = itemType;
		this.terminalDescription = terminalDescription;
		this.capacity = capacity;
		this.availableCapacity = availableCapacity;
		this.status = status;
		this.harborLocation = harborLocation;
	}

	public Terminal() {
		super();
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getTerminalName() {
		return terminalName;
	}

	public void setTerminalName(String terminalName) {
		this.terminalName = terminalName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getTerminalDescription() {
		return terminalDescription;
	}

	public void setTerminalDescription(String terminalDescription) {
		this.terminalDescription = terminalDescription;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public Integer getAvailableCapacity() {
		return availableCapacity;
	}

	public void setAvailableCapacity(Integer availableCapacity) {
		this.availableCapacity = availableCapacity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getHarborLocation() {
		return harborLocation;
	}

	public void setHarborLocation(String harborLocation) {
		this.harborLocation = harborLocation;
	}
	  public TerminalDTO convertEntitytoDTO(Terminal terminal) {
		  TerminalDTO terminalDTO = new TerminalDTO();
		  terminalDTO.setTerminalId(terminal.getTerminalId());
		  terminalDTO.setTerminalName(terminal.getTerminalName());
		  terminalDTO.setCountry(terminal.getCountry());
		  terminalDTO.setItemType(terminal.getItemType());
		  terminalDTO.setTerminalDescription(terminal.getTerminalDescription());
		  terminalDTO.setCapacity(terminal.getCapacity());
		  terminalDTO.setStatus(terminal.getStatus());
		  terminalDTO.setHarborLocation(terminal.getHarborLocation());
		  terminalDTO.setAvailableCapacity(terminal.getAvailableCapacity());
		  return terminalDTO;
	  }
}
