package com.demo.terminal.controller; 
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.terminal.dto.ResponseMessage;
import com.demo.terminal.dto.TerminalDTO;
import com.demo.terminal.exception.ItemNotFoundException;
import com.demo.terminal.service.TerminalService;



 @RestController()
 @RequestMapping("/ftr/terminals")
 public class TerminalController {

     @Autowired
     TerminalService terminalService;

       @GetMapping
       public ResponseEntity<List<TerminalDTO>> fetchFTRTerminals(){

       return ResponseEntity.ok().body(terminalService.fetchFTRTerminals());
       }

       @GetMapping("/fetchTerminalByItemType/{itemType}")
       public ResponseEntity<List<TerminalDTO>> fetchTerminalByItemType(@PathVariable String itemType) throws ItemNotFoundException{ 
       	return ResponseEntity.ok().body (terminalService.fetchTerminalByItemType(itemType));
       }
       @GetMapping("/fetchAvailableTerminalByItemType/{itemType}")
       public ResponseEntity<TerminalDTO> fetchAvailableTerminalByItemType(@PathVariable String itemType) throws ItemNotFoundException{ 
       	return ResponseEntity.ok().body (terminalService.fetchAvailableTerminalByItemType(itemType));
       }
       @PutMapping(value="/{terminalId}/{newCapacity}")
       public ResponseEntity<ResponseMessage> updateTerminal(@PathVariable("terminalId") String terminalId, @PathVariable("newCapacity") Integer newCapacity) throws ItemNotFoundException{
    	   String message= terminalService.updateTerminal(terminalId,newCapacity);
    	   ResponseMessage response = new ResponseMessage();
   	       response.setMessage(message);
    	   ResponseEntity<ResponseMessage> entity = new ResponseEntity<>(response,HttpStatus.ACCEPTED);
    	   return entity;
       }

       @GetMapping("/fetchTerminalByTerminalId/{terminalId}")
       public ResponseEntity<TerminalDTO> fetchTerminalByTerminalId (@PathVariable String terminalId) throws ItemNotFoundException{ 
       	return ResponseEntity.ok().body (terminalService.fetchTerminalByTerminalId(terminalId));
       }
        @DeleteMapping("/terminals/{terminalId}") 
       public ResponseEntity<ResponseMessage> removeTerminal(@PathVariable String terminalId) throws ItemNotFoundException{ 
         String message=terminalService.removeTerminal(terminalId);
         ResponseMessage response = new ResponseMessage();
 	      response.setMessage(message);
       	 return ResponseEntity.ok(response);
        }
       @PostMapping
       public ResponseEntity<ResponseMessage> insertNewTerminal(@RequestBody TerminalDTO terminalDTO) throws ItemNotFoundException { 
    	   String message=terminalService.insertNewTerminal (terminalDTO);
           ResponseMessage response = new ResponseMessage();
   	      response.setMessage(message);
         	 return ResponseEntity.ok(response);
       
       }

}



