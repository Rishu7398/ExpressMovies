package com.demo.terminal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.demo.terminal.entity.Terminal;

@Repository
public interface TerminalRepository extends JpaRepository<Terminal, String>{
  @Query("select f from Terminal f where f.itemType = ?1")
  public List<Terminal> fetchTerminalByItemType(@Param(value = "itemType") String itemType);
  
  @Query("select f from Terminal f where f.terminalId=?1")
  public Terminal findByTerminalId(String terminalId);
}
