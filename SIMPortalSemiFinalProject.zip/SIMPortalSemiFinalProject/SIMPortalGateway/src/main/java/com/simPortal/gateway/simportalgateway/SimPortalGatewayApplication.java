package com.simPortal.gateway.simportalgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimPortalGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimPortalGatewayApplication.class, args);
	}

}
