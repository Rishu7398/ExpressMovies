package com.simPortal.gateway.simportalgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimPortalGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
