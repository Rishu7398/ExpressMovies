package com.customerMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.customerMS.DTO.SimDTO;
import com.customerMS.controller.CustGetSimFeign;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
@Service
public class CustCircuitBreakerService {
	@Autowired
	RestTemplate template;
	
	@Autowired
	CustGetSimFeign  getSimFeign;
	
	@CircuitBreaker(name="customerService")
	public SimDTO getSpecificSim(Integer simId) {
		//return template.getForObject("http://SimMS/simcards/specificSimDetails/"+simId,SimDTO.class);
		return getSimFeign.getSpecificSim(simId);
	}
                         //Not used Asynchronous communication because in my case one rest endpoint is dependent on other
	
	
	@CircuitBreaker(name="customerService")
	public String setSimStatus(Integer simId) {
//return template.getForObject("http://SimMS/simcards/setSimStatusActive/"+simId+"/active", String.class);
		return getSimFeign.setSimStatus(simId);
	}
}
