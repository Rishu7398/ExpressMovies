package com.customerMS.exceptionHandler;

import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.hibernate.cfg.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.customerMS.util.ErrorMessage;



@RestControllerAdvice
public class GlobalExceptionHandler {

	private Environment environment;
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorMessage> methodArgumentExceptionHandler(MethodArgumentNotValidException ex)
	{
		ErrorMessage error = new ErrorMessage();
		error.setMessage(ex.getBindingResult().getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(", ")));
		error.setStatusCode(HttpStatus.BAD_REQUEST.value());
		error.setUrl("/customer/?/?");
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorMessage> constraintViolationExceptionHandler(ConstraintViolationException ex){
		ErrorMessage error = new ErrorMessage();
		error.setMessage(ex.getConstraintViolations().stream().map(ConstraintViolation::getMessage).collect(Collectors.joining(", ")));
		error.setStatusCode(HttpStatus.BAD_REQUEST.value());
        error.setUrl("/customer/?/?");
        return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
//	@ExceptionHandler(NullPointerException.class)
//	public ResponseEntity<ErrorMessage> nullPointerExceptionHandler(NullPointerException ex){
//		ErrorMessage error = new ErrorMessage();
//		//error.setMessage("{nullPointer.Exception.invalid}");
//		error.setMessage("Enter valid EmailAddress/ DateOfBirth");
//		error.setStatusCode(HttpStatus.BAD_REQUEST.value());
//		error.setUrl("/customer/?/?");
//		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
//	}
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<String> ExceptionHandler(Exception e){
  	  ResponseEntity<String> entity = new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
  	  return entity;
    }
	
}
