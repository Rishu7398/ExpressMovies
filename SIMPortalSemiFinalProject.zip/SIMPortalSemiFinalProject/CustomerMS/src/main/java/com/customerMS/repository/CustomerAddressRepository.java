package com.customerMS.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.customerMS.entity.CustomerAddress;




@Repository
public interface CustomerAddressRepository extends JpaRepository<CustomerAddress,Integer> {
    @Modifying
    @Transactional
	@Query("update CustomerAddress c set c.address=?1 , c.pincode=?2 , c.city=?3 , c.state=?4 where c.addressId=?5")
	public void updateAddressById(String address, Integer pincode, String city, String state, Integer addressId);
}
