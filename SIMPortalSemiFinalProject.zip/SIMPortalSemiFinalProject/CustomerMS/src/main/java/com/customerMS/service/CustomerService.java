package com.customerMS.service;

import java.time.LocalDate;

import com.customerMS.DTO.AddressDTO;
import com.customerMS.DTO.CustomerDTO;
import com.customerMS.DTO.CustomerValidationDTO;
import com.customerMS.entity.Customer;

public interface CustomerService {
  // public String validateCustomer(CustomerValidationDTO dto) throws Exception;
   public Customer validateIDAndActivate(CustomerDTO dto) throws Exception;
  public String customerValidation(String emailAddress, LocalDate dateOfBirth) throws Exception;
  public String customerDetailConfirmation(CustomerValidationDTO dto) throws Exception;
  public String customerAddressUpdation(AddressDTO dto);
}
