package com.customerMS.controller;

import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import com.customerMS.DTO.AddressDTO;
import com.customerMS.DTO.CustomerDTO;
import com.customerMS.DTO.CustomerValidationDTO;
import com.customerMS.DTO.SimDTO;
import com.customerMS.entity.Customer;
import com.customerMS.entity.CustomerActivatedSIM;
import com.customerMS.service.CustCircuitBreakerService;
import com.customerMS.service.CustomerService;
//import com.fasterxml.jackson.annotation.JsonFormat;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
//@RequestMapping("/customer")
@Validated
public class CustomerController {
    @Autowired
    CustomerService  service;
    
    @Autowired
    private DiscoveryClient client;
    
    @Autowired
    CustCircuitBreakerService custCircuitBreakerService;
    
    String simUri;
    
    CustomerActivatedSIM customer = new CustomerActivatedSIM();
    
    // 1. endpoint of customer
    @GetMapping(value="/customer/{emailAddress}/{dateOfbirth}")
    public ResponseEntity<String> customerValidation(@PathVariable @Email(regexp="[a-z0-9._%+-]+@ [a-z0-9.-]+\\.[a-z]{2,3}",message="{customer.Email.formatNotSpecified}") @NotNull String emailAddress, 
    		@PathVariable  @NotNull String dateOfbirth) throws Exception{
    	 LocalDate dateOfBirth = LocalDate.parse(dateOfbirth);
    	String s = service.customerValidation(emailAddress,dateOfBirth);
    	customer.setEmailAddress(emailAddress);
    	customer.setDateOfBirth(dateOfBirth);
    	  ResponseEntity<String> entity = new ResponseEntity<>(s,HttpStatus.ACCEPTED);
    	  return entity;
    }
    //2. endpoint for customer
    @PostMapping(value="/customer/detailConfirmation",consumes=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> customerDetailsConfirmation(@RequestBody @Valid CustomerValidationDTO dto) throws Exception{
    	String s = service.customerDetailConfirmation(dto);
    	customer.setFirstName(dto.getFirstName());
    	customer.setLastName(dto.getLastName());
      ResponseEntity<String> entity = new ResponseEntity<>(s,HttpStatus.ACCEPTED);
   	  return entity;
    }
    
    //3. endpoint for customer
    @PutMapping(value="/customer/updateCustomerAddress",consumes=MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> customerAddressUpdation(@RequestBody @Valid AddressDTO dto) {
    	String s = service.customerAddressUpdation(dto);
    	customer.setState(dto.getState());
        ResponseEntity<String> entity = new ResponseEntity<>(s,HttpStatus.ACCEPTED);
     	  return entity;
    }
    
   //4. endpoint for customer
    @PostMapping("/customer/idproofValidation")
    public ResponseEntity<CustomerActivatedSIM> CheckForIDValidationAndActivate(@RequestBody @Valid CustomerDTO dto) throws Exception{
    	Customer cust = null;
         cust=service.validateIDAndActivate(dto);
         String s= "ID Proof Validated";
         customer.setFirstName(cust.getFirstName());
         customer.setEmailAddress(cust.getEmailAddress());
         customer.setDateOfBirth(cust.getDateOfBirth());
         customer.setIdProffStatus(s);
         customer.setLastName(cust.getLastName());
         customer.setState(cust.getState());
          customer.setIdType(dto.getIdType());
          customer.setUniqueIdNumber(dto.getUniqueIdNumber());
          customer.setSimId(cust.getSimId());
          customer.setSimStatus("SIM Activation in progress! Will activated in next 2 hours.");
     	  ResponseEntity<CustomerActivatedSIM> entity = new ResponseEntity<>(customer,HttpStatus.ACCEPTED);
     	  return entity;
    }
    
    
            // fetching specific Sim Status
    @CircuitBreaker(name="customerService",fallbackMethod="getSpecificSimStatusFallback")
    @GetMapping("/customer/getSpecificSimStatus/{simId}")
    public ResponseEntity<SimDTO> getSpecificSimStatus(@PathVariable("simId") Integer simId) throws Exception{
        
/* List<ServiceInstance> listOfSIMInstances = client.getInstances("SimMS");
   if(listOfSIMInstances!=null && !listOfSIMInstances.isEmpty())
     simUri=listOfSIMInstances.get(0).getUri().toString();
   SimDTO simDTO= new RestTemplate().getForObject(simUri+"/simcards/specificSimDetails/"+sId,SimDTO.class); */
      
//SimDTO simDTO= template.getForObject("http://SimMS/simcards/specificSimDetails/"+simId,SimDTO.class);
      
      SimDTO simDTO= custCircuitBreakerService.getSpecificSim(simId);
      
      Integer sId=simDTO.getSimId();
     
//String status= new RestTemplate().getForObject(simUri+"/simcards/setSimStatusActive/"+sId+"/active", String.class);
//String status= template.getForObject("http://SimMS/simcards/setSimStatusActive/"+sId+"/active", String.class);
      String status= custCircuitBreakerService.setSimStatus(sId);
      simDTO.setSimStatus(status);
      ResponseEntity<SimDTO> entity = new ResponseEntity<>(simDTO,HttpStatus.ACCEPTED);
 	  return entity;
    }
    
    public ResponseEntity<SimDTO> getSpecificSimStatusFallback(Integer simId, Throwable throwable){
    	SimDTO simDTO=new SimDTO();
    	
    	String status="Id proof validated but Not Able To Activate";
    	simDTO.setSimStatus(status);
    	ResponseEntity<SimDTO> entity = new ResponseEntity<>(simDTO,HttpStatus.ACCEPTED);
   	  return entity;
    }

    
}
