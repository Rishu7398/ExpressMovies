package com.customerMS.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;



@Entity

public class CustomerAddress {
	   @Id
	   @Column(name="addressid")
	   @GeneratedValue(strategy=GenerationType.AUTO)
       private Integer addressId;
	   @Length(max=25, message = "{customerAddress.addressLength.Large}")
       private String address;
	   @Pattern(regexp="^[A-Za-z]+$",message="{customerAddress.city.specialCharacter}")
       private String city;
	   @Min(100000)
	   @Max(999999)
       private Integer pincode;
	   @Pattern(regexp="^[A-Za-z]+$",message="{customerAddress.city.specialCharacter}")
       private String state;
	   
       @OneToOne(mappedBy="customerAddress")
       private Customer customer;

       
	 public CustomerAddress() {
		super();
	}
	 
	public CustomerAddress(@Length(max=25, message = "{customerAddress.addressLength.Large}") String address,
			@Pattern(regexp = "^[A-Za-z]+$", message = "{customerAddress.city.specialCharacter}") String city,
			@Min(100000) @Max(999999) Integer pincode,
			@Pattern(regexp = "^[A-Za-z]+$", message = "{customerAddress.city.specialCharacter}") String state) {
		super();
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
	}
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Customer Address [Address Id= " + addressId +", Address= " + address + ", City= " + city + ", Pincode= " + pincode + ", State= " + state + "]";
	}
	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
       
}
