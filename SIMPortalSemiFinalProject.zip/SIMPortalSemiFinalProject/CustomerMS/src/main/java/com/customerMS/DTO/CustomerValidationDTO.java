package com.customerMS.DTO;


import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CustomerValidationDTO {

	@Email(message="{customerIdentity.Email.formatNotSpecified}")
	@NotNull
	private String emailAddress;
	
	@Length(max=15)
	@NotBlank(message="{customerValidation.firstName.blank}")
	@NotNull
	private String firstName;
	
	@Length(max=15)
	@NotBlank(message="{customerValidation.lastName.blank}")
	@NotNull
	private String lastName;
	
	//@Past(message="{customerIdentity.DOB.invalid}")
	@JsonFormat(pattern = "yyyy-MM-dd")
	@NotNull
	private LocalDate dateOfBirth;

	
	public CustomerValidationDTO(
			@Email(message = "{customerIdentity.Email.formatNotSpecified}") @NotNull String emailAddress,
			@NotBlank(message = "{customerValidation.firstName.blank}") @NotNull String firstName,
			@NotBlank(message = "{customerValidation.lastName.blank}") @NotNull String lastName) {
		super();
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	
	public CustomerValidationDTO(
			@Email(message = "{customerIdentity.Email.formatNotSpecified}") @NotNull String emailAddress,
			@NotBlank(message = "{customerValidation.firstName.blank}") @NotNull String firstName,
			@NotBlank(message = "{customerValidation.lastName.blank}") @NotNull String lastName,
			 @NotNull LocalDate dateOfBirth) {
		super();
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
	}


	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public CustomerValidationDTO() {
		super();
	}
	
	
	
}
