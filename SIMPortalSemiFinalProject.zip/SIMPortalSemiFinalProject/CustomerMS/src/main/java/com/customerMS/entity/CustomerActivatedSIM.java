package com.customerMS.entity;

import java.time.LocalDate;


public class CustomerActivatedSIM {

private String uniqueIdNumber;
	
	
	private LocalDate dateOfBirth;
	
	private String emailAddress;

	
	
    private String firstName;
	
	
    private String lastName;
	
	
    private String idType;
	  
   
    private Integer simId;
    
   
    private String state;
    private String IdProffStatus;
     
    private String simStatus;
    

	
    
	public String getIdProffStatus() {
		return IdProffStatus;
	}




	public void setIdProffStatus(String idProffStatus) {
		IdProffStatus = idProffStatus;
	}




	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}




	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}




	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}




	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}




	public String getEmailAddress() {
		return emailAddress;
	}




	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}




	public String getFirstName() {
		return firstName;
	}




	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}




	public String getLastName() {
		return lastName;
	}




	public void setLastName(String lastName) {
		this.lastName = lastName;
	}




	public String getIdType() {
		return idType;
	}




	public void setIdType(String idType) {
		this.idType = idType;
	}








	public Integer getSimId() {
		return simId;
	}




	public void setSimId(Integer simId) {
		this.simId = simId;
	}




	public String getState() {
		return state;
	}




	public void setState(String state) {
		this.state = state;
	}




	public String getSimStatus() {
		return simStatus;
	}




	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}




	@Override
	public String toString() {
		return "Customer Activated Sim ->[UniqueIdNumber= "+ uniqueIdNumber + ", Date Of Birth= "+ dateOfBirth + ", Email Address= " + emailAddress + ", First name= "
	                      + firstName + ", Last name= "+ lastName + ", Id Type= " + idType + ", SimID= " + simId + ", State= " + state +", SIM Status= "+ simStatus+"]";
	}
    
    
}
