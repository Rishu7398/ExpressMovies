package com.customerMS.DTO;


import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.customerMS.entity.Customer;
import com.fasterxml.jackson.annotation.JsonFormat;



public class CustomerDTO {

	@Length(max=16)
	private String uniqueIdNumber;
	//Since not supporting in my java version
	//@Past(message = "{customer.DOB.invalid}")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;
	
//	@Email(message="{customer.Email.formatNotSpecified}")
//	@NotNull
//	private String emailAddress;

	
	@Length(max=15)
	@NotNull
    private String firstName;
	
	@Length(max=15)
    private String lastName;
	
	@NotNull
    private String idType;
	
//	@Max(999999)
//	@Min(100000)
//	private Integer pincode;
	
    @Pattern(regexp="^[A-Za-z]+$",message="{customer.state.specialCharacter}")
    @NotNull
    private String state;

	public CustomerDTO() {
		super();
	}

	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}

	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
//
//	public String getEmailAddress() {
//		return emailAddress;
//	}
//
//	public void setEmailAddress(String emailAddress) {
//		this.emailAddress = emailAddress;
//	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
   
	
//	public Integer getPincode() {
//		return pincode;
//	}
//
//	public void setPincode(Integer pincode) {
//		this.pincode = pincode;
//	}

//	public CustomerDTO(String uniqueIdNumber,  LocalDate dateOfBirth,
//			@Email(message = "{customer.Email.formatNotSpecified}") @NotNull String emailAddress,
//			@NotNull String firstName, String lastName, @NotNull String idType,
//			@Pattern(regexp = "^[A-Za-z]+$", message = "{customer.state.specialCharacter}") @NotNull String state) {
//		super();
//		this.uniqueIdNumber = uniqueIdNumber;
//		this.dateOfBirth = dateOfBirth;
//		this.emailAddress = emailAddress;
//		this.firstName = firstName;
//		this.lastName = lastName;
//		this.idType = idType;
//		this.state = state;
//	}
	
//    @Override
//    public String toString() {
//		return "Customer ->[UniqueIdNumber= "+ uniqueIdNumber + ", Date Of Birth= "+ dateOfBirth + ", Email Address= " + emailAddress + ", First name= "
//	                      + firstName + ", Last name= "+ lastName + ", Id Type= " + idType + ", State= " + state + "]";
//	}
//	
    public static Customer createEntity(CustomerDTO dto) {
    	Customer customer = new Customer();
    	customer.setDateOfBirth(dto.getDateOfBirth());
    	//customer.setEmailAddress(dto.getEmailAddress());
    	customer.setIdType(dto.getIdType());
    	customer.setLastName(dto.getLastName());
    	customer.setFirstName(dto.getFirstName());
    	customer.setState(dto.getState());
    	customer.setUniqueIdNumber(dto.getUniqueIdNumber());
    	return customer;
    }

public CustomerDTO(String uniqueIdNumber, LocalDate dateOfBirth, @NotNull String firstName, String lastName,
		@NotNull String idType,
		@Pattern(regexp = "^[A-Za-z]+$", message = "{customer.state.specialCharacter}") @NotNull String state) {
	super();
	this.uniqueIdNumber = uniqueIdNumber;
	this.dateOfBirth = dateOfBirth;
	this.firstName = firstName;
	this.lastName = lastName;
	this.idType = idType;
	this.state = state;
}
}
