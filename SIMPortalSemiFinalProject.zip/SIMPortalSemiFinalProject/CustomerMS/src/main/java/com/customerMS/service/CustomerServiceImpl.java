package com.customerMS.service;

import java.time.LocalDate;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customerMS.DTO.AddressDTO;
import com.customerMS.DTO.CustomerDTO;
import com.customerMS.DTO.CustomerValidationDTO;
import com.customerMS.entity.Customer;
import com.customerMS.entity.CustomerAddress;
import com.customerMS.repository.CustomerAddressRepository;
import com.customerMS.repository.CustomerRepository;
@Service("customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	CustomerAddressRepository customerAddressRepository;
	 public String customerValidation(String emailAddress, LocalDate dateOfBirth) throws Exception {
		 Customer cust = customerRepository.findByEmailAddressAndDateOfBirth(emailAddress,dateOfBirth);
		 if(cust.getUniqueIdNumber()==null) {
			 throw new Exception("Invalid Customer Details");
		 }
		 else {
			 return "Valid Customer";
		 }
	 }
     
	  public String customerDetailConfirmation(CustomerValidationDTO dto) throws Exception{
		  String firstName=dto.getFirstName();
			String lastName = dto.getLastName();
			String email= dto.getEmailAddress();
			//LocalDate date=dto.getDateOfBirth();
			Customer cust = customerRepository.findByFirstNameAndLastName(firstName,lastName);
			if(cust==null) {
				throw new Exception("No customer found for the provided detail");
			}
			else if(cust.getEmailAddress().equals(email)) {
				return "Email Validated";
			}
			else {
				throw new Exception("Invalid Email details");
			}
			
	  }
	 
	  public String customerAddressUpdation(AddressDTO dto) {
		  Optional<CustomerAddress> customerAddress = customerAddressRepository.findById(dto.getAddressId());
		  if(customerAddress.isEmpty()) {
			  CustomerAddress cust = dto.createEntity(dto);
			  
			  customerAddressRepository.saveAndFlush(cust);
			  return "Address added";
		  }
		  else {
			  customerAddressRepository.updateAddressById(dto.getAddress(),dto.getPincode(),dto.getCity(),dto.getState(),dto.getAddressId());
			  return "New Address Updated Successfully";
		  }
	  }
	  
	  
	  
	@Override
	public Customer validateIDAndActivate(CustomerDTO dto) throws Exception {
		// TODO Auto-generated method stub
		Customer customer = customerRepository.findById(dto.getUniqueIdNumber()).get();
		if(customer.getFirstName().equals(dto.getFirstName()) && customer.getLastName().equals(dto.getLastName())) {
			if(customer.getDateOfBirth().equals(dto.getDateOfBirth())) {
				return customer;
			}
			else {
				throw new Exception("Incorrect date Of Birth Details");
			}
		}
		else {
			throw new Exception("Invalid Details");
		}
		
	}
}
