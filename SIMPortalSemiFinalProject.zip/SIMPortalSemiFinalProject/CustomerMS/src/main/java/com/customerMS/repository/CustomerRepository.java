package com.customerMS.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.customerMS.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,String> {
    @Query("select u from Customer u where u.emailAddress=?1 and u.dateOfBirth=?2")
	Customer findByEmailAddressAndDateOfBirth(String emailAddress, LocalDate dateOfBirth);
    @Query("select u from Customer u where u.firstName=?1 and u.lastName=?2")
    Customer findByFirstNameAndLastName(String firstName, String lastName);
}
