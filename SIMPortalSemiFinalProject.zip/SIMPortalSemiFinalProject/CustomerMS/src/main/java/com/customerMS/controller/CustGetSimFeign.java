package com.customerMS.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.customerMS.DTO.SimDTO;

@FeignClient(name="SimMS",url="http://localhost:9000/")
public interface CustGetSimFeign {

	@RequestMapping("/simcards/specificSimDetails/{simId}")
	SimDTO getSpecificSim(@PathVariable("simId") Integer simId);
	
	@RequestMapping("/simcards/setSimStatusActive/{simId}/active")
	String setSimStatus(@PathVariable("simId") Integer simId);
}

