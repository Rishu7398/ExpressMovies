package com.simPortal.controller;

import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.simPortal.SimDTO;
import com.simPortal.entity.SimOffers;
import com.simPortal.exceptionHandler.VariableNullPointerException;
import com.simPortal.service.SimPortalServices;

@RestController
@RequestMapping("/simcards")
@Validated
public class SimCardController {
     @Autowired
     SimPortalServices service;
     
     @GetMapping(value="/{simNumber}/{serviceNumber}")
     public ResponseEntity<SimOffers> showOfferDetails(@PathVariable @Pattern(regexp="[0-9]{13}", message= "{simDetails.simNumber.invalid}") String simNumber,@PathVariable @Pattern(regexp="[0-9]{10}",message="{simDetails.serviceNumber.invalid}") String serviceNumber) throws Exception{
    	SimOffers s=service.showOfferDetails(simNumber,serviceNumber);
    	 ResponseEntity<SimOffers> entity=new ResponseEntity<>(s,HttpStatus.ACCEPTED);
    	 return entity;
     }
     
     @GetMapping(value="/specificSimDetails/{simId}")
     public SimDTO getSpecificSimDetails(@PathVariable("simId") Integer simId) {
    	 return service.getSpecificSimDetails(simId);
     }
     @GetMapping(value="/setSimStatusActive/{simId}/{simStatus}")
     public String setSimStatus(@PathVariable("simId") Integer simId, @PathVariable("simStatus") String simStatus) {
    	 return service.setSimStatusActive(simId,simStatus);
     }
     
}
