package com.simPortal.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.simPortal.entity.SimDetails;
@Repository
public interface SimDetailsRepository extends JpaRepository<SimDetails,Integer>{
	@Query("select u from SimDetails u where u.simNumber=?1 and u.serviceNumber=?2")
     SimDetails findBySimNumberAndServiceNumber(String simNumber,String serviceNumber);
	@Modifying
    @Transactional
	@Query("update SimDetails c set c.simStatus=?2 where c.simId=?1")
    void updateSimStatusBySimId(Integer simId,String simStatus);
}
