package com.simPortal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value= {"simOffers","customer"})
public class SimDetails {
    @Id
    @Column(name="simid")
	private Integer simId;
	private String serviceNumber;
	private String simNumber;
	private String simStatus;
	@OneToOne(mappedBy="simDetails")
	private SimOffers simOffers;
//	@OneToOne(mappedBy="simDetail")
//	private Customer customer;
	public SimDetails(Integer simId, String serviceNumber, String simNumber, String simStatus, SimOffers simOffers) {
		super();
		this.simId = simId;
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
		this.simStatus = simStatus;
		this.simOffers = simOffers;
	}
	public SimOffers getSimOffers() {
		return simOffers;
	}
	public void setSimOffers(SimOffers simOffers) {
		this.simOffers = simOffers;
	}
	public SimDetails() {}
	public SimDetails(Integer simId, String serviceNumber, String simNumber, String simStatus) {
		super();
		this.simId = simId;
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
		this.simStatus = simStatus;
	}
	public Integer getSimId() {
		return simId;
	}
	public void setSimId(Integer simId) {
		this.simId = simId;
	}
	public String getServiceNumber() {
		return serviceNumber;
	}
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	public String getSimNumber() {
		return simNumber;
	}
	public void setSimNumber(String simNumber) {
		this.simNumber = simNumber;
	}
	public String getSimStatus() {
		return simStatus;
	}
	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}
	
	
}
