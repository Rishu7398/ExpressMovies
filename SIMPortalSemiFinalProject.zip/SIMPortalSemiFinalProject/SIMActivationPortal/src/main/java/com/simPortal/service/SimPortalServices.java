package com.simPortal.service;

import com.simPortal.SimDTO;
import com.simPortal.entity.SimOffers;

public interface SimPortalServices {
     public SimOffers showOfferDetails(String simNumber,String serviceNumber) throws Exception;
     public SimDTO getSpecificSimDetails(Integer simId);
     public String setSimStatusActive(Integer simId, String simStatus);
}
