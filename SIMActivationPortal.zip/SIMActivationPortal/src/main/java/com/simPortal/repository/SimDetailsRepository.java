package com.simPortal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.simPortal.entity.SimDetails;
@Repository
public interface SimDetailsRepository extends JpaRepository<SimDetails,Integer>{
	@Query("select u from SimDetails u where u.simNumber=?1 and u.serviceNumber=?2")
     SimDetails findBySimNumberAndServiceNumber(String simNumber,String serviceNumber); 
	@Query(value="select * from sim_details where sim_status =?1",nativeQuery=true)
	public List<SimDetails> findAnyAndActivate(String status);
}
