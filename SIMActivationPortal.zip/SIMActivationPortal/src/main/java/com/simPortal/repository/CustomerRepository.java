package com.simPortal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.simPortal.entity.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer,String> {

}
