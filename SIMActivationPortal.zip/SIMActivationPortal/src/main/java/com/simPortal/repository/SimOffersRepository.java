package com.simPortal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.simPortal.entity.SimOffers;
@Repository
public interface SimOffersRepository extends JpaRepository<SimOffers,Integer> {
	@Query("select u from SimOffers u where u.simDetails.simId=?1")
	SimOffers findBySimId(Integer simId);
}
