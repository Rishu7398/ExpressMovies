package com.simPortal.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.simPortal.DTO.CustomerDTO;
import com.simPortal.DTO.CustomerValidationDTO;
import com.simPortal.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
      
	@Autowired
	private CustomerService service;
	
	@PostMapping("/validateCustomerDetails")
	public ResponseEntity<Object> validateCustomerDetails(@RequestBody @Valid CustomerValidationDTO dto) throws Exception {
		String message = service.validateCustomer(dto);
		HashMap<String,Object> hashmap =new HashMap<>();
		hashmap.put("data", message);
		return ResponseEntity.ok(hashmap);
	}
	
	@PostMapping("/idproofValidation")
	public ResponseEntity<Object> checkForIDAndActivate(@RequestBody @Valid CustomerDTO dto) throws Exception{
		
		Object dataFromService = service.validateIDAndActivate(dto);
		return ResponseEntity.ok(dataFromService);
	}
}
