package com.simPortal.DTO;

import javax.persistence.OneToOne;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.simPortal.entity.Customer;
import com.simPortal.entity.CustomerAddress;

public class AddressDTO {
    private Integer addressId;
    
    @Length(max=25, message= "{customerAddress.addressLength.Large}")
    private String address;
    
    @Pattern(regexp="^[A-Za-z]+$",message="{customerAddress.city.specialCharacter}")
    @NotNull
    private String city;
    
    @Min(100000)
    @Max(999999)
    private Integer pincode;
    
    @Pattern(regexp="^[A-Za-z]+$",message="{customerAddress.city.specialCharacter}")
    @NotNull
    private String state;
    
    @OneToOne(mappedBy="customerAddress")
    @JsonIgnore
    private Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public AddressDTO(String address,
			@Pattern(regexp = "^[A-Za-z]+$", message = "{customerAddress.city.specialCharacter}") @NotNull String city,
			@Min(100000) @Max(999999) Integer pincode,
			@Pattern(regexp = "^[A-Za-z]+$", message = "{customerAddress.city.specialCharacter}") @NotNull String state) {
		super();
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
	}
    
	@Override
	public String toString() {
		return "Customer Address [Address Id= " + addressId +", Address= " + address + ", City= " + city + ", Pincode= " + pincode + ", State= " + state + "]";
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
    
	public static CustomerAddress createEntity(AddressDTO dto) {
		CustomerAddress customerAddress = new CustomerAddress();
		customerAddress.setAddress(dto.getAddress());
		customerAddress.setCity(dto.getCity());
		customerAddress.setPincode(dto.getPincode());
		customerAddress.setState(dto.getState());
		return customerAddress;
	}
    
    
}
