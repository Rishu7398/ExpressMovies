package com.simPortal.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;
//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity

public class CustomerIdentity {
    @Id
    @Column(name="uniqueidnumber")
    @Length(max=16)
	private String uniqueIdNumber;
    @JsonFormat(pattern="yyyy-MM-dd")
    @Past(message="{customerIdentity.DOB.invalid}")
	private LocalDate dateOfBirth;
    @Length(max=15)
	private String firstName;
    @Length(max=15)
	private String lastName;
    @Email(message="{customerIdentity.Email.formatNotSpecified}")
	private String emailAddress;
	private String state;
	public CustomerIdentity() {
		super();
	}
	public CustomerIdentity(String uniqueIdNumber,
			@Past(message = "{customerIdentity.DOB.invalid}") LocalDate dateOfBirth,@Length(max=15) String firstName,@Length(max=15) String lastName,
			@Email(message = "{customerIdentity.Email.formatNotSpecified}") String emailAddress, String state) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.state = state;
	}
	@Override
	public String toString() {
		return "Customer Identity ->[UniqueIdNumber= "+ uniqueIdNumber + ", Date Of Birth= "+ dateOfBirth + ", First name= "
	                      + firstName + ", Last name= "+ lastName + ", Email Address= " + emailAddress + ", State= " + state + "]";
	}
	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
