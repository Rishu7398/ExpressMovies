package com.simPortal.entity;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity

public class SimOffers {
	@Id
	@Column(name="offerid")
    private Integer offerId;
    private Integer callQty;
    private Integer cost;
    private Integer dataQty;
    private Integer duration;
    private String offerName;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="simid",unique=true)
    private SimDetails simDetails;
    public SimOffers() {
    	
    }
	public SimOffers(Integer offerId, Integer callQty, Integer cost, Integer dataQty, Integer duration,
			String offerName, SimDetails simDetails) {
		super();
		this.offerId = offerId;
		this.callQty = callQty;
		this.cost = cost;
		this.dataQty = dataQty;
		this.duration = duration;
		this.offerName = offerName;
		this.simDetails = simDetails;
	}
	public Integer getOfferId() {
		return offerId;
	}
	public void setOfferId(Integer offerId) {
		this.offerId = offerId;
	}
	public Integer getCallQty() {
		return callQty;
	}
	public void setCallQty(Integer callQty) {
		this.callQty = callQty;
	}
	public Integer getCost() {
		return cost;
	}
	public void setCost(Integer cost) {
		this.cost = cost;
	}
	public Integer getDataQty() {
		return dataQty;
	}
	public void setDataQty(Integer dataQty) {
		this.dataQty = dataQty;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public String getOfferName() {
		return offerName;
	}
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}
	public SimDetails getSimDetails() {
		return simDetails;
	}
	public void setSimDetails(SimDetails simDetails) {
		this.simDetails = simDetails;
	}
    
}
