package com.simPortal.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
//import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value= {"simDetail","customerAddress"})
public class Customer {
	@Id
	@Length(max=16)
	private String uniqueIdNumber;
	
	@Past(message = "{customer.DOB.invalid}")
	@JsonFormat(pattern = "yyyy-MM-dd")
	@NotNull
	private LocalDate dateOfBirth;
	
	@Email(message="{customer.Email.formatNotSpecified}")
	@NotNull
	private String emailAddress;

	
	@Length(max=15)
	@NotNull
    private String firstName;
	
	@Length(max=15)
    private String lastName;
	
	@NotNull
    private String idType;
	
    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="addressid",unique=true)
    private CustomerAddress customerAddress;
    
    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="simid",unique=true)
    private SimDetails simDetail;
    
    @Pattern(regexp="^[A-Za-z]+$",message="{customer.state.specialCharacter}")
    @NotNull
    private String state;

    
	public Customer() {
		super();
	}

	public String getUniqueIdNumber() {
		return uniqueIdNumber;
	}

	public void setUniqueIdNumber(String uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public CustomerAddress getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(CustomerAddress customerAddress) {
		this.customerAddress = customerAddress;
	}

	public SimDetails getSimDetail() {
		return simDetail;
	}

	public void setSimDetail(SimDetails simDetail) {
		this.simDetail = simDetail;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Customer(String uniqueIdNumber, @Past(message = "{customer.DOB.invalid}") @NotNull LocalDate dateOfBirth,
			@Email(message = "{customer.Email.formatNotSpecified}") @NotNull String emailAddress,
			@NotNull String firstName, String lastName, String idType, CustomerAddress customerAddress,
			SimDetails simDetail,
			@Pattern(regexp = "^[A-Za-z]+$", message = "{customer.state.specialCharacter}") @NotNull String state) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.idType = idType;
		this.customerAddress = customerAddress;
		this.simDetail = simDetail;
		this.state = state;
	}
    
	@Override
	public String toString() {
		return "Customer ->[UniqueIdNumber= "+ uniqueIdNumber + ", Date Of Birth= "+ dateOfBirth + ", Email Address= " + emailAddress + ", First name= "
	                      + firstName + ", Last name= "+ lastName + ", Id Type= " + idType + ", Customer Address= " + customerAddress + ", SIM details= " + simDetail + ", State= " + state + "]";
	}
    
    
}
