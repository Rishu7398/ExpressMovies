package com.simPortal.exceptionHandler;

public class VariableNullPointerException extends Exception {
	public VariableNullPointerException(String msg){
		super(msg);
	}
}
