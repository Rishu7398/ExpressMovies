package com.simPortal.service;

import com.simPortal.DTO.CustomerDTO;
import com.simPortal.DTO.CustomerValidationDTO;

public interface CustomerService {
   public String validateCustomer(CustomerValidationDTO dto) throws Exception;
   public Object validateIDAndActivate(CustomerDTO dto) throws Exception;
}
