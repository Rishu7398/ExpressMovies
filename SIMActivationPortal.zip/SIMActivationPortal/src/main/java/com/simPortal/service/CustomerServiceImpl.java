package com.simPortal.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simPortal.DTO.CustomerDTO;
import com.simPortal.DTO.CustomerValidationDTO;
import com.simPortal.entity.Customer;
import com.simPortal.entity.CustomerAddress;
import com.simPortal.entity.CustomerIdentity;
import com.simPortal.entity.SimDetails;
import com.simPortal.repository.CustomerAddressRepository;
import com.simPortal.repository.CustomerIdentityRepository;
import com.simPortal.repository.CustomerRepository;
import com.simPortal.repository.SimDetailsRepository;
import com.simPortal.repository.SimOffersRepository;

@Service("customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerIdentityRepository customerIdentityRepository;
	
	@Autowired
	private CustomerAddressRepository customerAddressRepository;
	 
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	SimDetailsRepository simDetailsRepository;
	
	@Autowired
	SimOffersRepository simOffersRepository;
	
	public String validateCustomer(CustomerValidationDTO dto) throws Exception{
		
		String firstName=dto.getFirstName();
		String lastName = dto.getLastName();
		String email= dto.getEmailAddress();
		LocalDate date=dto.getDateOfBirth();
		
		Optional<CustomerIdentity> optionalCustomerIdentity = customerIdentityRepository.findByFirstNameLastNameAndEmail(firstName,lastName,email);
		if(optionalCustomerIdentity.isEmpty()) {
			throw new Exception("Customer is unAvailable");
		}
		if(!optionalCustomerIdentity.get().getDateOfBirth().equals(date)) {
			throw new Exception("No request is placed for you");
		}
		return "VALID CUSTOMER";
	}
	
	public static Integer getRandomNumber(int min, int max) {
		Random random = new Random();
		return random.nextInt(max-min) + min;
	}
	
	public Object validateIDAndActivate(CustomerDTO dto) throws Exception {
		
		Optional<CustomerIdentity> customerOptional = customerIdentityRepository.findById(dto.getUniqueIdNumber());
		
		if(customerOptional.isEmpty()) {
			throw new Exception("Invalid Details");
		}
		
		CustomerIdentity customerFromRecords =customerOptional.get();
		if(customerFromRecords.getFirstName().toLowerCase().equals(dto.getFirstName().toLowerCase()) && 
				customerFromRecords.getLastName().toLowerCase().equals(dto.getLastName().toLowerCase()) &&
				customerFromRecords.getDateOfBirth().equals(dto.getDateOfBirth())) {
			
			Optional<CustomerAddress> addressOptional = customerAddressRepository.findByPincode(dto.getPincode());
			
			CustomerAddress customerAddress;
			if(!addressOptional.isPresent()) {
				customerAddress= new CustomerAddress();
				customerAddress.setPincode(dto.getPincode());
				customerAddress.setState(dto.getState());
			}
			else {
				customerAddress = addressOptional.get();
			}
			
			List<SimDetails> availableSimCards = simDetailsRepository.findAnyAndActivate("inactive");
			
			int size = availableSimCards.size();
			if(size==0) {
				throw new Exception("No SIMcard Available Contact Service Provider");
			}
			int generateRandomNumber = CustomerServiceImpl.getRandomNumber(0,size);
			
			if(generateRandomNumber<0) {
				throw new Exception("Out of Range");
			}
			
			SimDetails simToBeAlloted = availableSimCards.get(generateRandomNumber);
			simToBeAlloted.setSimStatus("active");
			simDetailsRepository.save(simToBeAlloted);
			
			Customer customer = CustomerDTO.createEntity(dto);
			customer.setSimDetail(simToBeAlloted);
			customer.setCustomerAddress(customerAddress);
			
			customerRepository.save(customer);
			
			HashMap<String, Object> dataObject = new HashMap<>();
			dataObject.put("SimActiveStatus", "active");
			dataObject.put("CustomerDetails", customer);
			dataObject.put("SimDetails", customer.getSimDetail());
			dataObject.put("Verified Through", customer.getIdType());
			SimDetails s=customer.getSimDetail();
			int sId = s.getSimId();
			dataObject.put("SimOffers", simOffersRepository.findBySimId(sId));
			dataObject.put("AddressUsedForVerification", customerAddress);
			dataObject.put("Activated on", LocalDateTime.now());
			return dataObject;
		}
		else {
			throw new Exception("Details provided is invalid");
		}
		
	}

}
