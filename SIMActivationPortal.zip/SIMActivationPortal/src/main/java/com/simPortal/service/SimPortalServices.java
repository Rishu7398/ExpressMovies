package com.simPortal.service;

import com.simPortal.entity.SimOffers;

public interface SimPortalServices {
     public SimOffers showOfferDetails(String simNumber,String serviceNumber) throws Exception;
}
