package com.simPortal.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simPortal.entity.SimDetails;
import com.simPortal.entity.SimOffers;
import com.simPortal.exceptionHandler.VariableNullPointerException;
import com.simPortal.repository.SimDetailsRepository;
import com.simPortal.repository.SimOffersRepository;

@Service("simPortalServices")
@Transactional
public class SimPortalServicesImpl implements SimPortalServices{
      @Autowired
      SimDetailsRepository simDetailsRepository;
      @Autowired
      SimOffersRepository simOffersRepository;
      
      public SimOffers showOfferDetails(String simNumber,String serviceNumber) throws Exception{
    	  SimDetails sd=simDetailsRepository.findBySimNumberAndServiceNumber(simNumber,serviceNumber);
    	  
    	  Integer simId=sd.getSimId();
    	  if(simId==null) {
    		  throw new Exception();
    	  }else {
    		  if(sd.getSimStatus().equals("active")) {
    			  throw new Exception("SIM already active");
    		  }else {
    	  SimOffers so=simOffersRepository.findBySimId(simId);
    	  return so;}}
    	  
      }
}
